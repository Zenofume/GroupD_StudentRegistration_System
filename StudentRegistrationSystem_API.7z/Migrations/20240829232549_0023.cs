﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentRegistrationSystem.Migrations
{
    /// <inheritdoc />
    public partial class _0023 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Departments",
                table: "Students",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Schools",
                table: "Students",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SchoolID",
                table: "Departments",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Departments_SchoolID",
                table: "Departments",
                column: "SchoolID");

            migrationBuilder.AddForeignKey(
                name: "FK_Departments_Schools_SchoolID",
                table: "Departments",
                column: "SchoolID",
                principalTable: "Schools",
                principalColumn: "SchoolID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Departments_Schools_SchoolID",
                table: "Departments");

            migrationBuilder.DropIndex(
                name: "IX_Departments_SchoolID",
                table: "Departments");

            migrationBuilder.DropColumn(
                name: "Departments",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "Schools",
                table: "Students");

            migrationBuilder.DropColumn(
                name: "SchoolID",
                table: "Departments");
        }
    }
}
