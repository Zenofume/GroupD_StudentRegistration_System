﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// Controller for managing students within the Student Registration System.
    /// Provides endpoints to perform CRUD operations and other actions on student data.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="StudentsController"/> class.
        /// </summary>
        /// <param name="context">The database context to access student data.</param>
        public StudentsController(StudentRegistrationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves a list of all students.
        /// </summary>
        /// <returns>A list of all students.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudents()
        {
            return await _context.Students.ToListAsync();
        }

        /// <summary>
        /// Retrieves a specific student by their ID.
        /// </summary>
        /// <param name="studentid">The ID of the student to retrieve.</param>
        /// <returns>The student with the specified ID.</returns>
        [HttpGet("findStudentid")]
        public async Task<ActionResult<Student>> GetStudent(int studentid)
        {
            var student = await _context.Students.FindAsync(studentid);

            if (student == null)
            {
                return NotFound();
            }

            return student;
        }

        /// <summary>
        /// Updates an existing student's details.
        /// </summary>
        /// <param name="editid">The ID of the student to update.</param>
        /// <param name="updateStudent">The new details for the student.</param>
        /// <returns>A message indicating whether the update was successful.</returns>
        [HttpPatch("{editid}")]
        public async Task<IActionResult> UpdateStudent(int editid, [FromBody] UpdateStudentDto updateStudent)
        {
            var student = await _context.Students.FindAsync(editid);

            if (student == null)
                return NotFound(new { Message = "Student not found!" });

            // Check if the student has reached the update limit
            if (student.UpdateCount >= 1)
                return BadRequest(new { Message = "Student Already registered.!!!" });

            // Update student details if provided in the request
            if (!string.IsNullOrEmpty(updateStudent.OtherName))
                student.OtherName = updateStudent.OtherName;

            if (updateStudent.Dob.HasValue)
                student.Dob = updateStudent.Dob.Value;

            if (!string.IsNullOrEmpty(updateStudent.Gender))
                student.Gender = updateStudent.Gender;

            if (!string.IsNullOrEmpty(updateStudent.Nationality))
                student.Nationality = updateStudent.Nationality;

            if (!string.IsNullOrEmpty(updateStudent.MaritialStatus))
                student.MaritialStatus = updateStudent.MaritialStatus;

            if (!string.IsNullOrEmpty(updateStudent.PhoneNumber))
                student.PhoneNumber = updateStudent.PhoneNumber;

            if (!string.IsNullOrEmpty(updateStudent.Email))
                student.Email = updateStudent.Email;

            student.Course1 = updateStudent.Course1 ?? student.Course1;
            student.Course2 = updateStudent.Course2 ?? student.Course2;
            student.Course3 = updateStudent.Course3 ?? student.Course3;
            student.Course4 = updateStudent.Course4 ?? student.Course4;
            student.Course5 = updateStudent.Course5 ?? student.Course5;
            student.Course6 = updateStudent.Course6 ?? student.Course6;
            student.Course7 = updateStudent.Course7 ?? student.Course7;

            if (updateStudent.SchoolId.HasValue)
                student.SchoolId = updateStudent.SchoolId.Value;

            if (updateStudent.DepartmentId.HasValue)
                student.DepartmentId = updateStudent.DepartmentId.Value;

            if (updateStudent.CourseProgramId.HasValue)
                student.CourseProgramId = updateStudent.CourseProgramId.Value;

            if (updateStudent.DateRegister.HasValue)
                student.DateRegister = updateStudent.DateRegister.Value;
            student.DateRegister = DateTime.UtcNow;

            // Increment update count
            student.UpdateCount++;

            // Save changes to the database
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Student record updated successfully!" });
        }

        /// <summary>
        /// Deletes a specific student by their ID.
        /// </summary>
        /// <param name="studentID">The ID of the student to delete.</param>
        /// <returns>A message indicating whether the deletion was successful.</returns>
        [HttpPost("{studentID:int}")]
        public async Task<IActionResult> DeleteStudent(int studentID)
        {
            var student = await _context.Students.FirstOrDefaultAsync(u => u.StudentId == studentID);

            if (student == null)
                return NotFound(new { Message = "Student not found!" });

            _context.Students.Remove(student);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "(1) Student deleted successfully!" });
        }

        /// <summary>
        /// Retrieves the details of the currently authenticated student.
        /// </summary>
        /// <returns>The details of the currently authenticated student.</returns>
        [HttpGet("me")]
        [Authorize(Roles = "Student")]
        public async Task<ActionResult<Student>> GetMyDetails()
        {
            // Get the current user's Student ID from the claims
            var studentId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.StudentId == studentId);

            if (student == null)
            {
                return NotFound(new { Message = "Student record not found." });
            }

            return student;
        }

        /// <summary>
        /// Updates the details of the currently authenticated student.
        /// </summary>
        /// <param name="updateStudent">The new details for the student.</param>
        /// <returns>A message indicating whether the update was successful.</returns>
        [HttpPatch("me")]
        [Authorize(Roles = "Student")]
        public async Task<IActionResult> UpdateMyDetails([FromBody] UpdateStudentDto updateStudent)
        {
            // Get the current user's Student ID from the claims
            var studentId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value);

            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.StudentId == studentId);

            if (student == null)
            {
                return NotFound(new { Message = "Student record not found." });
            }

            // Update student details if provided in the request
            if (!string.IsNullOrEmpty(updateStudent.OtherName))
                student.OtherName = updateStudent.OtherName;

            if (updateStudent.Dob.HasValue)
                student.Dob = updateStudent.Dob.Value;

            if (!string.IsNullOrEmpty(updateStudent.Gender))
                student.Gender = updateStudent.Gender;

            if (!string.IsNullOrEmpty(updateStudent.Nationality))
                student.Nationality = updateStudent.Nationality;

            if (!string.IsNullOrEmpty(updateStudent.MaritialStatus))
                student.MaritialStatus = updateStudent.MaritialStatus;

            if (!string.IsNullOrEmpty(updateStudent.PhoneNumber))
                student.PhoneNumber = updateStudent.PhoneNumber;

            if (!string.IsNullOrEmpty(updateStudent.Email))
                student.Email = updateStudent.Email;

            student.Course1 = updateStudent.Course1 ?? student.Course1;
            student.Course2 = updateStudent.Course2 ?? student.Course2;
            student.Course3 = updateStudent.Course3 ?? student.Course3;
            student.Course4 = updateStudent.Course4 ?? student.Course4;
            student.Course5 = updateStudent.Course5 ?? student.Course5;
            student.Course6 = updateStudent.Course6 ?? student.Course6;
            student.Course7 = updateStudent.Course7 ?? student.Course7;

            if (updateStudent.SchoolId.HasValue)
                student.SchoolId = updateStudent.SchoolId.Value;

            if (updateStudent.DepartmentId.HasValue)
                student.DepartmentId = updateStudent.DepartmentId.Value;

            if (updateStudent.CourseProgramId.HasValue)
                student.CourseProgramId = updateStudent.CourseProgramId.Value;

            if (updateStudent.DateRegister.HasValue)
                student.DateRegister = updateStudent.DateRegister.Value;

            // Increment update count
            student.UpdateCount++;

            // Save changes to the database
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Student record updated successfully!" });
        }

        /// <summary>
        /// Retrieves a paginated list of students.
        /// </summary>
        /// <param name="page">The page number to retrieve (default is 1).</param>
        /// <param name="pageSize">The number of students per page (default is 10).</param>
        /// <returns>A paginated list of students.</returns>
        [HttpGet("paged")]
        public async Task<ActionResult<IEnumerable<Student>>> GetPagedStudents(int page = 1, int pageSize = 10)
        {
            var students = await _context.Students
                .OrderBy(s => s.StudentId) // Or any other sorting criteria
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(students);
        }

        /// <summary>
        /// Retrieves a paginated and searchable list of students.
        /// </summary>
        /// <param name="searchTerm">The search term to filter students by name.</param>
        /// <param name="page">The page number to retrieve (default is 1).</param>
        /// <param name="pageSize">The number of students per page (default is 10).</param>
        /// <returns>A paginated and searchable list of students.</returns>
        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<Student>>> GetSearchableStudents(
            string searchTerm = "",
            int page = 1,
            int pageSize = 10)
        {
            var query = _context.Students.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(s =>
                    s.OtherName.Contains(searchTerm) ||
                    s.PhoneNumber.Contains(searchTerm) ||
                    s.Email.Contains(searchTerm));
            }

            var students = await query
                .OrderBy(s => s.StudentId) // Or any other sorting criteria
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return Ok(students);
        }
    }
}
