﻿using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Services;
using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// API Controller responsible for administrative tasks, such as creating users and resetting passwords.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="AdminController"/> class.
        /// </summary>
        /// <param name="userService">The service handling user-related operations.</param>
        /// <param name="context">The database context for accessing user data.</param>
        public AdminController(UserService userService, StudentRegistrationDbContext context)
        {
            _context = context;
            _userService = userService;
        }

        /// <summary>
        /// Creates a new user with the specified role.
        /// </summary>
        /// <param name="request">The user creation request containing user details and role.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("create-user")]
        public async Task<IActionResult> CreateUser([FromBody] CreateUserRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Role))
            {
                return BadRequest("Invalid request.");
            }

            // Check if the username already exists
            var existingUser = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == request.Username);

            if (existingUser != null)
            {
                return BadRequest(new { message = "User already exists." });
            }

            if (request.Role == "Student")
            {
                // Create a new Student entity
                var student = new Student
                {
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    StudentIDNumber = request.Username, // Assuming StudentIDNumber as Username
                    Departments = request.Departments,
                    Schools = request.Schools,
                    Programs = request.Programs
                    // Other fields will be null or defaults
                };

                // Add the student to the context and save changes
                _context.Students.Add(student);
                await _context.SaveChangesAsync();

                // Create a new user for the student
                var user = await _userService.CreateStudentUserAsync(student);
                return CreatedAtAction(nameof(CreateUser), new { id = user.UserId }, user);
            }
            else if (request.Role == "Admin")
            {
                // Create a new user for the admin
                var user = await _userService.CreateAdminUserAsync(request.Username);
                return CreatedAtAction(nameof(CreateUser), new { id = user.UserId }, user);
            }
            else
            {
                return BadRequest("Invalid Role.");
            }
        }

        /// <summary>
        /// Resets the password of an existing user.
        /// </summary>
        /// <param name="request">The request containing the username for which the password is to be reset.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Username))
            {
                return BadRequest("Username is required.");
            }

            // Find the user by username
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == request.Username);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            // Reset the user's password
            await _userService.ResetPasswordAsync(user);

            return Ok(new { message = "Password reset successfully." });
        }

        /// <summary>
        /// Retrieves a list of all users.
        /// </summary>
        /// <returns>A list of users.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetSchools()
        {
            return await _context.Users.ToListAsync();
        }

        /// <summary>
        /// Represents a request to create a new user.
        /// </summary>
        public class CreateUserRequest
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string Username { get; set; }
            public string Departments { get; set; }
            public string Schools { get; set; }
            public string Programs { get; set; }
            public string Role { get; set; } // 'student' or 'admin'
        }

        /// <summary>
        /// Represents a request to reset a user's password.
        /// </summary>
        public class ResetPasswordRequest
        {
            [Required]
            public string Username { get; set; }
        }
    }
}
