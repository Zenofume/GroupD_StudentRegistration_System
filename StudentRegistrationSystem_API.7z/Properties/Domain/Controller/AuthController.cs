﻿//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Build.Framework;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.IdentityModel.Tokens;
//using StudentRegistrationSystem.Properties.Domain.DBContext;
//using StudentRegistrationSystem.Properties.Domain.Entity;
//using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
//using StudentRegistrationSystem.Properties.Domain.Services;

//namespace StudentRegistrationSystem.Controllers;

//[ApiController]
//[Route("api/[controller]")]
//public class AuthController : ControllerBase
//{
//    private readonly UserService _userService;
//    private readonly IConfiguration _configuration;
//    private readonly StudentRegistrationDbContext _context;

//    public AuthController(UserService userService, StudentRegistrationDbContext context, IConfiguration configuration)
//    {
//        _userService = userService;
//        _configuration = configuration;
//        _context = context;
//    }


//    [HttpPost("login")]
//    public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
//    {
//        var user = await _userService.AuthenticateAsync(loginDto.Username, loginDto.Password);
//        if (user == null)
//        {
//            return Unauthorized();
//        }

//        if (user.IsPasswordResetRequired)
//        {
//            return BadRequest(new { message = "Password reset required." });
//        }

//        var token = GenerateJwtToken(user);

//        return Ok(new { token });
//    }



//    [HttpPost("change-password")]
//    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
//    {
//        // Check if the user exists
//        var user = await _userService.GetUserByUsernameAsync(changePasswordDto.Username);

//        if (user == null)
//        {
//            // If the user is not found
//            return NotFound(new { message = "User not found." });
//        }

//        // Authenticate the user
//        bool isCurrentPasswordValid = await _userService.ValidateCurrentPasswordAsync(user, changePasswordDto.CurrentPassword);

//        if (!isCurrentPasswordValid)
//        {
//            // If the current password is incorrect
//            return Unauthorized(new { message = "Current password is incorrect." });
//        }

//        // Change the password
//        bool isPasswordChanged = await _userService.ChangePasswordAsync(user, changePasswordDto.NewPassword);

//        if (!isPasswordChanged)
//        {
//            // Handle case where password change fails
//            return StatusCode(StatusCodes.Status500InternalServerError, new { message = "Failed to change the password. Please try again later." });
//        }

//        return Ok(new { message = "Password changed successfully." });
//    }



//    [HttpPost("refresh")]
//    public async Task<IActionResult> Refresh([FromBody] TokenApiDto tokenApiDto)
//    {
//        if (tokenApiDto is null)
//            return BadRequest("Invalid Client Request");
//        string accessToken = tokenApiDto.AccessToken;
//        string refreshToken = tokenApiDto.RefreshToken;
//        var principal = _userService.GetPrincipleFromExpiredToken(accessToken);
//        var username = principal.Identity.Name;
//        var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
//        if (user is null || user.RefreshToken != refreshToken || user.RefreshTokenExpiryTime >= DateTime.Now)
//            return BadRequest("Invalid Request");
//        var newAccessToken = _userService.CreateJwt(user);
//        var newRefreshToken = _userService.CreateRefreshToken();
//        user.RefreshToken = newRefreshToken;
//        await _context.SaveChangesAsync();
//        return Ok(new TokenApiDto()
//        {
//            AccessToken = newAccessToken,
//            RefreshToken = newRefreshToken,
//        });
//    }

//    private string GenerateJwtToken(User user)
//    {
//        var key = _configuration["JwtKey"];
//        if (string.IsNullOrEmpty(key))
//        {
//            throw new InvalidOperationException("JWT Key is not configured.");
//        }

//        var claims = new[]
//        {
//        new Claim(ClaimTypes.Name, user.Username),
//        new Claim(ClaimTypes.Role, user.Role)
//    };

//        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
//        var creds = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

//        var token = new JwtSecurityToken(
//            claims: claims,
//            expires: DateTime.Now.AddMinutes(30),
//            signingCredentials: creds);

//        return new JwtSecurityTokenHandler().WriteToken(token);
//    }



//    public class LoginDto
//    {
//        [Required]
//        public string Username { get; set; }

//        [Required]
//        public string Password { get; set; }
//    }

//    public class ChangePasswordDto
//    {
//        [Required]
//        public string Username { get; set; }  // Optional if you want the user to identify themselves

//        [Required]
//        public string CurrentPassword { get; set; }

//        [Required]
//        public string NewPassword { get; set; }
//    }

//}

using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
using StudentRegistrationSystem.Properties.Domain.Services;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// The AuthController handles user authentication, password management, and token refresh operations.
    /// </summary>
   
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserService _userService;
        private readonly IConfiguration _configuration;
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthController"/> class.
        /// </summary>
        /// <param name="userService">The user service for authentication and user management.</param>
        /// <param name="context">The database context for accessing user data.</param>
        /// <param name="configuration">The configuration settings for the application.</param>
        public AuthController(UserService userService, StudentRegistrationDbContext context, IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
            _context = context;
        }

        /// <summary>
        /// Authenticates a user and generates a JWT token.
        /// </summary>
        /// <param name="loginDto">The login details provided by the user.</param>
        /// <returns>An ActionResult containing the JWT token if authentication is successful, or an error message if it fails.</returns>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
        {
            var user = await _userService.AuthenticateAsync(loginDto.Username, loginDto.Password);
            if (user == null)
            {
                return Unauthorized();
            }

            if (user.IsPasswordResetRequired)
            {
                return BadRequest(new { message = "Password reset required." });
            }

            var token = GenerateJwtToken(user);

            return Ok(new { token });
        }

        /// <summary>
        /// Changes the password of an authenticated user.
        /// </summary>
        /// <param name="changePasswordDto">The DTO containing the current and new passwords.</param>
        /// <returns>An ActionResult indicating the outcome of the password change operation.</returns>
        [HttpPost("change-password")]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
        {
            var user = await _userService.GetUserByUsernameAsync(changePasswordDto.Username);

            if (user == null)
            {
                return NotFound(new { message = "User not found." });
            }

            bool isCurrentPasswordValid = await _userService.ValidateCurrentPasswordAsync(user, changePasswordDto.CurrentPassword);

            if (!isCurrentPasswordValid)
            {
                return Unauthorized(new { message = "Current password is incorrect." });
            }

            bool isPasswordChanged = await _userService.ChangePasswordAsync(user, changePasswordDto.NewPassword);

            if (!isPasswordChanged)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = "Failed to change the password. Please try again later." });
            }

            return Ok(new { message = "Password changed successfully." });
        }

        /// <summary>
        /// Refreshes an expired JWT token using a valid refresh token.
        /// </summary>
        /// <param name="tokenApiDto">The DTO containing the expired access token and the valid refresh token.</param>
        /// <returns>An ActionResult containing a new access token and refresh token if successful, or an error message if it fails.</returns>
        [HttpPost("refresh")]
        public async Task<IActionResult> Refresh([FromBody] TokenApiDto tokenApiDto)
        {
            if (tokenApiDto is null)
            {
                return BadRequest("Invalid Client Request");
            }

            string accessToken = tokenApiDto.AccessToken;
            string refreshToken = tokenApiDto.RefreshToken;

            var principal = _userService.GetPrincipleFromExpiredToken(accessToken);
            var username = principal.Identity.Name;
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);

            if (user is null || user.RefreshToken != refreshToken || user.RefreshTokenExpiryTime >= DateTime.Now)
            {
                return BadRequest("Invalid Request");
            }

            var newAccessToken = _userService.CreateJwt(user);
            var newRefreshToken = _userService.CreateRefreshToken();

            user.RefreshToken = newRefreshToken;
            await _context.SaveChangesAsync();

            return Ok(new TokenApiDto()
            {
                AccessToken = newAccessToken,
                RefreshToken = newRefreshToken,
            });
        }

        /// <summary>
        /// Generates a JWT token for an authenticated user.
        /// </summary>
        /// <param name="user">The user for whom the token is generated.</param>
        /// <returns>A JWT token as a string.</returns>
        private string GenerateJwtToken(User user)
        {
            var key = _configuration["JwtKey"];
            if (string.IsNullOrEmpty(key))
            {
                throw new InvalidOperationException("JWT Key is not configured.");
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var creds = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        /// <summary>
        /// DTO for handling login requests.
        /// </summary>
        public class LoginDto
        {
            [Required]
            public string Username { get; set; }

            [Required]
            public string Password { get; set; }
        }

        /// <summary>
        /// DTO for handling password change requests.
        /// </summary>
        public class ChangePasswordDto
        {
            [Required]
            public string Username { get; set; }

            [Required]
            public string CurrentPassword { get; set; }

            [Required]
            public string NewPassword { get; set; }
        }
    }
}

