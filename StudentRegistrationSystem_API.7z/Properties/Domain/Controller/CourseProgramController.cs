﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// API Controller responsible for managing Course Programs.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class CourseProgramController : ControllerBase
    {
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="CourseProgramController"/> class.
        /// </summary>
        /// <param name="context">The database context for accessing course programs.</param>
        public CourseProgramController(StudentRegistrationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves all Course Programs from the database.
        /// </summary>
        /// <returns>A list of all Course Programs.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseProgram>>> GetCoursePrograms()
        {
            return await _context.CoursePrograms.ToListAsync();
        }

        /// <summary>
        /// Retrieves a specific Course Program by its ID.
        /// </summary>
        /// <param name="courseProgramid">The ID of the Course Program to retrieve.</param>
        /// <returns>The Course Program with the specified ID, or a 404 error if not found.</returns>
        [HttpGet("findCourseProgramlid")]
        public async Task<ActionResult<CourseProgram>> GetCourseProgram(int courseProgramid)
        {
            var courseProgram = await _context.CoursePrograms.FindAsync(courseProgramid);

            if (courseProgram == null)
            {
                return NotFound();
            }

            return courseProgram;
        }

        /// <summary>
        /// Updates an existing Course Program with new details.
        /// </summary>
        /// <param name="editid">The ID of the Course Program to update.</param>
        /// <param name="updatecourseProgram">The new details for the Course Program.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPatch("{editid}")]
        public async Task<IActionResult> UpdateCourseProgram(int editid, [FromBody] UpdateCourseProgramDto updatecourseProgram)
        {
            var courseProgram = await _context.CoursePrograms.FindAsync(editid);

            if (courseProgram == null)
                return NotFound(new { Message = "Course Program not found!" });

            // Update course program properties if they are provided
            if (!string.IsNullOrEmpty(updatecourseProgram.CourseProgramName))
                courseProgram.CourseProgramName = updatecourseProgram.CourseProgramName;

            if (!string.IsNullOrEmpty(updatecourseProgram.CourseLevel))
                courseProgram.CourseLevel = updatecourseProgram.CourseLevel;

            if (!string.IsNullOrEmpty(updatecourseProgram.Semester))
                courseProgram.Semester = updatecourseProgram.Semester;

            if (!string.IsNullOrEmpty(updatecourseProgram.AcademicYear))
                courseProgram.AcademicYear = updatecourseProgram.AcademicYear;

            // Save changes to the database
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Course Program updated successfully!" });
        }

        /// <summary>
        /// Adds a new Course Program to the database.
        /// </summary>
        /// <param name="courseProgram">The details of the Course Program to add.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("addcourseprogram")]
        public async Task<IActionResult> AddCourseProgram([FromBody] CourseProgramDto courseProgram)
        {
            // Check if a Course Program with the same name already exists
            var existingCourseProgram = await _context.CoursePrograms
                .FirstOrDefaultAsync(d => d.CourseProgramName == courseProgram.CourseProgramName);

            if (existingCourseProgram != null)
            {
                // If it exists, return an error response
                return BadRequest(new
                {
                    Status = 400,
                    Message = "A Course Program with this name already exists."
                });
            }

            // If not, add the new Course Program
            var newCourseProgram = new CourseProgram
            {
                CourseProgramName = courseProgram.CourseProgramName,
                CourseLevel = courseProgram.CourseLevel,
                Semester = courseProgram.Semester,
                AcademicYear = courseProgram.AcademicYear
            };

            await _context.CoursePrograms.AddAsync(newCourseProgram);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = 200,
                Message = "Course Program added successfully"
            });
        }

        /// <summary>
        /// Deletes a specific Course Program by its ID.
        /// </summary>
        /// <param name="courseProgramID">The ID of the Course Program to delete.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("{courseProgramID:int}")]
        public async Task<IActionResult> DeleteCourseProgram(int courseProgramID)
        {
            var courseProgram = await _context.CoursePrograms.FirstOrDefaultAsync(u => u.CourseProgramID == courseProgramID);

            if (courseProgram == null)
                return NotFound(new { Message = "Course Program not found!" });

            // Remove the Course Program from the database
            _context.CoursePrograms.Remove(courseProgram);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Course Program deleted successfully!" });
        }
    }
}
