﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using StudentRegistrationSystem.Properties.Domain.DBContext;
//using StudentRegistrationSystem.Properties.Domain.Entity;
//using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace StudentRegistrationSystem.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class CourseController : ControllerBase
//    {
//        private readonly StudentRegistrationDbContext _context;

//        public CourseController(StudentRegistrationDbContext context)
//        {
//            _context = context;
//        }

//        // GET: api/Course
//        [HttpGet]
//        public async Task<ActionResult<IEnumerable<Course>>> GetCourses()
//        {
//            return await _context.Courses.ToListAsync();
//        }

//        // GET: api/Course/5
//        [HttpGet("findCourseid")]
//        public async Task<ActionResult<Course>> GetCourse(int courseid)
//        {
//            var course = await _context.Courses.FindAsync(courseid);

//            if (course == null)
//            {
//                return NotFound();
//            }

//            return course;
//        }

//        // PUT: api/Course/5
//        [HttpPatch("{editid}")]
//        public async Task<IActionResult> UpdateCourse(int editid, [FromBody] UpdateCourseDto updatecourse)
//        {

//            var course = await _context.Courses.FindAsync(editid);

//            if (course == null)
//                return NotFound(new { Message = "Course not found!" });

//            // Update course properties if they are provided
//            if (!string.IsNullOrEmpty(updatecourse.CourseName))
//                course.CourseName = updatecourse.CourseName;

//            if (!string.IsNullOrEmpty(updatecourse.CourseCode))
//                course.CourseCode = updatecourse.CourseCode;

//            // Save changes to the database
//            await _context.SaveChangesAsync();

//            return Ok(new { Message = "Course Program updated successfully!" });
//        }

//        // POST: api/Course
//        [HttpPost("addcourse")]
//        public async Task<IActionResult> AddCourse([FromBody] CourseDto course)
//        {
//            // Check if a department with the same name already exists
//            var existingCourse = await _context.Courses
//                .FirstOrDefaultAsync(d => d.CourseName == course.CourseName);

//            if (existingCourse != null)
//            {
//                // If it exists, return an error response
//                return BadRequest(new
//                {
//                    Status = 400,
//                    Message = "A Course with this name already exists."
//                });
//            }

//            // If not, add the new department
//            var newCourse = new Course
//            {
//                CourseName = course.CourseName,
//                CourseCode = course.CourseCode


//            };

//            await _context.Courses.AddAsync(newCourse);
//            await _context.SaveChangesAsync();

//            return Ok(new
//            {
//                Status = 200,
//                Message = "(1) Course added successfully"
//            });
//        }
//        // DELETE: api/Course/5
//        [HttpPost("{courseID:int}")]
//        public async Task<IActionResult> DeleteCoure(int courseID)
//        {
//            var course = await _context.Courses.FirstOrDefaultAsync(u => u.CourseId == courseID);

//            if (course == null)
//                return NotFound(new { Message = "Course not found!" });


//            _context.Courses.Remove(course);
//            await _context.SaveChangesAsync();

//            return Ok(new { Message = "(1) Course deleted successfully!" });
//        }
//    }

   
//}
