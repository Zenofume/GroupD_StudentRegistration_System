﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// API Controller for managing Departments within the Student Registration System.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="DepartmentController"/> class.
        /// </summary>
        /// <param name="context">The database context used to access department data.</param>
        public DepartmentController(StudentRegistrationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves all Departments from the database.
        /// </summary>
        /// <returns>A list of all Departments.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Department>>> GetDepartments()
        {
            return await _context.Departments.ToListAsync();
        }

        /// <summary>
        /// Retrieves a specific Department by its ID.
        /// </summary>
        /// <param name="departmentid">The ID of the Department to retrieve.</param>
        /// <returns>The Department with the specified ID, or a 404 error if not found.</returns>
        [HttpGet("finddepartmentid")]
        public async Task<ActionResult<Department>> GetDepartment(int departmentid)
        {
            var department = await _context.Departments.FindAsync(departmentid);

            if (department == null)
            {
                return NotFound();
            }

            return department;
        }

        /// <summary>
        /// Updates an existing Department with new details.
        /// </summary>
        /// <param name="editid">The ID of the Department to update.</param>
        /// <param name="updatedepartment">The new details for the Department.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPatch("{editid}")]
        public async Task<IActionResult> UpdateDepartment(int editid, [FromBody] UpdateDepartmentDto updatedepartment)
        {
            var department = await _context.Departments.FindAsync(editid);

            if (department == null)
                return NotFound(new { Message = "Department not found!" });

            // Update department properties if they are provided
            if (!string.IsNullOrEmpty(updatedepartment.DepartmentName))
                department.DepartmentName = updatedepartment.DepartmentName;

            await _context.SaveChangesAsync();

            return Ok(new { Message = "Department updated successfully!" });
        }

        /// <summary>
        /// Adds a new Department to the database.
        /// </summary>
        /// <param name="department">The details of the Department to add.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("adddepartment")]
        public async Task<IActionResult> AddDepartment([FromBody] DepartmentDto department)
        {
            // Check if a department with the same name already exists
            var existingDepartment = await _context.Departments
                .FirstOrDefaultAsync(d => d.DepartmentName == department.DepartmentName);

            if (existingDepartment != null)
            {
                // If it exists, return an error response
                return BadRequest(new
                {
                    Status = 400,
                    Message = "A department with this name already exists."
                });
            }

            // If not, add the new department
            var newDepartment = new Department
            {
                DepartmentName = department.DepartmentName
            };

            await _context.Departments.AddAsync(newDepartment);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = 200,
                Message = "Department added successfully"
            });
        }

        /// <summary>
        /// Deletes a specific Department by its ID.
        /// </summary>
        /// <param name="departmentID">The ID of the Department to delete.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("{departmentID:int}")]
        public async Task<IActionResult> DeleteDepartment(int departmentID)
        {
            var department = await _context.Departments.FirstOrDefaultAsync(u => u.DepartmentID == departmentID);

            if (department == null)
                return NotFound(new { Message = "Department not found!" });

            // Remove the Department from the database
            _context.Departments.Remove(department);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "Department deleted successfully!" });
        }
    }
}
