﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;
using StudentRegistrationSystem.Properties.Domain.Entity.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StudentRegistrationSystem.Controllers
{
    /// <summary>
    /// API Controller for managing Schools within the Student Registration System.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolController : ControllerBase
    {
        private readonly StudentRegistrationDbContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="SchoolController"/> class.
        /// </summary>
        /// <param name="context">The database context used to access school data.</param>
        public SchoolController(StudentRegistrationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves all Schools from the database.
        /// </summary>
        /// <returns>A list of all Schools.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<School>>> GetSchools()
        {
            return await _context.Schools.ToListAsync();
        }

        /// <summary>
        /// Retrieves a specific School by its ID.
        /// </summary>
        /// <param name="schoolid">The ID of the School to retrieve.</param>
        /// <returns>The School with the specified ID, or a 404 error if not found.</returns>
        [HttpGet("findschoolid")]
        public async Task<ActionResult<School>> GetSchool(int schoolid)
        {
            var school = await _context.Schools.FindAsync(schoolid);

            if (school == null)
            {
                return NotFound();
            }

            return school;
        }

        /// <summary>
        /// Updates an existing School with new details.
        /// </summary>
        /// <param name="editid">The ID of the School to update.</param>
        /// <param name="updateSchool">The new details for the School.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPatch("{editid}")]
        public async Task<IActionResult> UpdateSchool(int editid, [FromBody] UpdateSchoolDto updateSchool)
        {
            var school = await _context.Schools.FindAsync(editid);

            if (school == null)
                return NotFound(new { Message = "School not found!" });

            // Update school properties if they are provided
            if (!string.IsNullOrEmpty(updateSchool.SchoolName))
                school.SchoolName = updateSchool.SchoolName;

            // Save changes to the database
            await _context.SaveChangesAsync();

            return Ok(new { Message = "School updated successfully!" });
        }

        /// <summary>
        /// Adds a new School to the database.
        /// </summary>
        /// <param name="school">The details of the School to add.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("addschool")]
        public async Task<IActionResult> AddSchool([FromBody] SchoolDto school)
        {
            // Check if a school with the same name already exists
            var existingSchool = await _context.Schools
                .FirstOrDefaultAsync(d => d.SchoolName == school.SchoolName);

            if (existingSchool != null)
            {
                // If it exists, return an error response
                return BadRequest(new
                {
                    Status = 400,
                    Message = "A school with this name already exists."
                });
            }

            // If not, add the new school
            var newSchool = new School
            {
                SchoolName = school.SchoolName
            };

            await _context.Schools.AddAsync(newSchool);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = 200,
                Message = "School added successfully"
            });
        }

        /// <summary>
        /// Deletes a specific School by its ID.
        /// </summary>
        /// <param name="schoolID">The ID of the School to delete.</param>
        /// <returns>A response indicating success or failure.</returns>
        [HttpPost("{schoolID:int}")]
        public async Task<IActionResult> DeleteSchool(int schoolID)
        {
            var school = await _context.Schools.FirstOrDefaultAsync(u => u.SchoolID == schoolID);

            if (school == null)
                return NotFound(new { Message = "School not found!" });

            // Remove the School from the database
            _context.Schools.Remove(school);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "School deleted successfully!" });
        }
    }
}
