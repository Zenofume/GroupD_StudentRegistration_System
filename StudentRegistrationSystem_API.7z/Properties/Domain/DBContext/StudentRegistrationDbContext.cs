﻿using Microsoft.EntityFrameworkCore;
using StudentRegistrationSystem.Properties.Domain.Entity;
using System.Collections.Generic;

namespace StudentRegistrationSystem.Properties.Domain.DBContext
{
    /// <summary>
    /// Represents the database context for the Student Registration System.
    /// This context manages the entity sets and configures the relationships between them.
    /// </summary>
    public class StudentRegistrationDbContext : DbContext
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StudentRegistrationDbContext"/> class.
        /// </summary>
        /// <param name="options">The options to be used by the <see cref="DbContext"/>.</param>
        public StudentRegistrationDbContext(DbContextOptions options) : base(options) { }

        /// <summary>
        /// Gets or sets the DbSet for <see cref="User"/> entities.
        /// </summary>
        public DbSet<User> Users { get; set; }

        /// <summary>
        /// Gets or sets the DbSet for <see cref="Student"/> entities.
        /// </summary>
        public DbSet<Student> Students { get; set; }

        /// <summary>
        /// Gets or sets the DbSet for <see cref="School"/> entities.
        /// </summary>
        public DbSet<School> Schools { get; set; }

        /// <summary>
        /// Gets or sets the DbSet for <see cref="Department"/> entities.
        /// </summary>
        public DbSet<Department> Departments { get; set; }

        /// <summary>
        /// Gets or sets the DbSet for <see cref="CourseProgram"/> entities.
        /// </summary>
        public DbSet<CourseProgram> CoursePrograms { get; set; }

        // Uncomment the following line to add support for Course entities
        // public DbSet<Course> Courses { get; set; }

        /// <summary>
        /// Configures the relationships between entities in the model.
        /// </summary>
        /// <param name="modelBuilder">The builder used to configure the model.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure the one-to-one relationship between User and Student
            modelBuilder.Entity<User>()
                .HasOne(u => u.Student)
                .WithOne()
                .HasForeignKey<User>(u => u.StudentId);

            // Configure the many-to-one relationship between Student and CourseProgram
            modelBuilder.Entity<Student>()
                .HasOne(s => s.CourseProgram)
                .WithMany(cp => cp.Students)
                .HasForeignKey(s => s.CourseProgramId)
                .OnDelete(DeleteBehavior.Cascade); // Set the delete behavior as needed

            // Configure the many-to-one relationship between Student and Department
            modelBuilder.Entity<Student>()
                .HasOne(s => s.Department)
                .WithMany(dep => dep.Students)
                .HasForeignKey(s => s.DepartmentId);

            base.OnModelCreating(modelBuilder);
        }
    }
}
