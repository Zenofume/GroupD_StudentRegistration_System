﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using StudentRegistrationSystem.Properties.Domain.DBContext;
using StudentRegistrationSystem.Properties.Domain.Entity;

namespace StudentRegistrationSystem.Properties.Domain.Services
{
    /// <summary>
    /// Provides services related to user management including creation, authentication, password management, and token handling.
    /// </summary>
    public class UserService : IUserService
    {
        private readonly StudentRegistrationDbContext _context;
        private readonly IPasswordHasher<User> _passwordHasher;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserService"/> class.
        /// </summary>
        /// <param name="context">The database context used to access user data.</param>
        /// <param name="passwordHasher">The password hasher used to hash and verify passwords.</param>
        public UserService(StudentRegistrationDbContext context, IPasswordHasher<User> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        /// <summary>
        /// Creates a new student user with a default password.
        /// </summary>
        /// <param name="student">The student entity to base the new user on.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the created <see cref="User"/> entity.</returns>
        public async Task<User> CreateStudentUserAsync(Student student)
        {
            var user = new User
            {
                Username = student.StudentIDNumber,
                Role = "Student",
                StudentId = student.StudentId,
                PasswordHash = _passwordHasher.HashPassword(new User(), "default"),
                IsPasswordResetRequired = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }

        /// <summary>
        /// Creates a new admin user with a default password.
        /// </summary>
        /// <param name="username">The username for the new admin user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the created <see cref="User"/> entity.</returns>
        public async Task<User> CreateAdminUserAsync(string username)
        {
            var user = new User
            {
                Username = username,
                Role = "Admin",
                PasswordHash = _passwordHasher.HashPassword(null, "default-admin"),
                IsPasswordResetRequired = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return user;
        }

        /// <summary>
        /// Creates a JWT token for the specified user.
        /// </summary>
        /// <param name="user">The user entity for whom the token is being created.</param>
        /// <param name="accountNumber">Optional account number for additional claims.</param>
        /// <returns>A JWT token as a string.</returns>
        public string CreateJwt(User user, string accountNumber = null)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("your-32-byte-length-key-here.........");
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Role, user.Role),
            });

            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddHours(1),
                SigningCredentials = credentials
            };
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        }

        /// <summary>
        /// Creates a new refresh token.
        /// </summary>
        /// <returns>A new refresh token as a string.</returns>
        public string CreateRefreshToken()
        {
            var tokenBytes = RandomNumberGenerator.GetBytes(64);
            var refreshToken = Convert.ToBase64String(tokenBytes);

            var tokenInUser = _context.Users
                .Any(a => a.RefreshToken == refreshToken);
            if (tokenInUser)
            {
                return CreateRefreshToken();
            }
            return refreshToken;
        }

        /// <summary>
        /// Resets the password for the specified user to a default password.
        /// </summary>
        /// <param name="user">The user entity for whom the password needs to be reset.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task ResetPasswordAsync(User user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.PasswordHash = _passwordHasher.HashPassword(user, "default");
            user.IsPasswordResetRequired = true;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Authenticates a user with the provided username and password.
        /// </summary>
        /// <param name="username">The username of the user to authenticate.</param>
        /// <param name="password">The password of the user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the authenticated <see cref="User"/> entity, or null if authentication fails.</returns>
        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _context.Users.SingleOrDefaultAsync(u => u.Username == username);
            if (user == null || user.PasswordHash == null || _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, password) == PasswordVerificationResult.Failed)
            {
                return null;
            }
            return user;
        }

        /// <summary>
        /// Changes the password for the specified user to a new password.
        /// </summary>
        /// <param name="user">The user entity for which the password needs to be changed.</param>
        /// <param name="newPassword">The new password to set for the user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains a boolean value indicating whether the password change was successful.</returns>
        public async Task<bool> ChangePasswordAsync(User user, string newPassword)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));

            user.PasswordHash = _passwordHasher.HashPassword(user, newPassword);
            user.IsPasswordResetRequired = false;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
            return true;
        }

        /// <summary>
        /// Retrieves a user by their username.
        /// </summary>
        /// <param name="username">The username of the user to retrieve.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the <see cref="User"/> entity if found, or null if not.</returns>
        public async Task<User?> GetUserByUsernameAsync(string username)
        {
            return await _context.Users.SingleOrDefaultAsync(u => u.Username == username);
        }

        /// <summary>
        /// Validates the current password of the specified user.
        /// </summary>
        /// <param name="user">The user entity for which the current password needs to be validated.</param>
        /// <param name="currentPassword">The current password to validate.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains a boolean value indicating whether the current password is valid.</returns>
        public async Task<bool> ValidateCurrentPasswordAsync(User user, string currentPassword)
        {
            return _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, currentPassword) == PasswordVerificationResult.Success;
        }

        /// <summary>
        /// Parses a JWT token and extracts the claims from an expired token.
        /// </summary>
        /// <param name="token">The JWT token to parse.</param>
        /// <returns>The <see cref="ClaimsPrincipal"/> representing the claims contained in the token.</returns>
        /// <exception cref="SecurityTokenException">Thrown when the token is invalid.</exception>
        public ClaimsPrincipal GetPrincipleFromExpiredToken(string token)
        {
            var key = Encoding.ASCII.GetBytes("your-32-byte-length-key-here.........");
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateLifetime = false
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken securityToken;
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken);
            var jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("This is Invalid Token");

            // Log claims for debugging
            foreach (var claim in principal.Claims)
            {
                Console.WriteLine($"Claim Type: {claim.Type}, Claim Value: {claim.Value}");
            }

            return principal;
        }
    }
}
