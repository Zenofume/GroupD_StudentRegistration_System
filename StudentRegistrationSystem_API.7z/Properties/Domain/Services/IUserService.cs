﻿using System.Threading.Tasks;
using StudentRegistrationSystem.Properties.Domain.Entity;

namespace StudentRegistrationSystem.Properties.Domain.Services
{
    /// <summary>
    /// Defines the contract for user-related services, including student user creation, password management, and authentication.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Creates a new student user based on the provided student information.
        /// </summary>
        /// <param name="student">The student entity containing the information for the new user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the created <see cref="User"/> entity.</returns>
        Task<User> CreateStudentUserAsync(Student student);

        /// <summary>
        /// Resets the password for the specified user.
        /// </summary>
        /// <param name="user">The user entity for which the password needs to be reset.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        Task ResetPasswordAsync(User user);

        /// <summary>
        /// Authenticates a user based on the provided username and password.
        /// </summary>
        /// <param name="username">The username of the user.</param>
        /// <param name="password">The password of the user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains the authenticated <see cref="User"/> entity, or null if authentication fails.</returns>
        Task<User> AuthenticateAsync(string username, string password);

        /// <summary>
        /// Changes the password for the specified user to a new password.
        /// </summary>
        /// <param name="user">The user entity for which the password needs to be changed.</param>
        /// <param name="newPassword">The new password to set for the user.</param>
        /// <returns>A task representing the asynchronous operation. The task result contains a boolean value indicating whether the password change was successful.</returns>
        Task<bool> ChangePasswordAsync(User user, string newPassword);
    }
}
