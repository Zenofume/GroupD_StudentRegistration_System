﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a school entity with details about the school, its departments, and students.
    /// </summary>
    public class School
    {
        /// <summary>
        /// Gets or sets the unique identifier for the school.
        /// </summary>
        [Key]
        public int SchoolID { get; set; }

        /// <summary>
        /// Gets or sets the name of the school.
        /// </summary>
        public string? SchoolName { get; set; }

        /// <summary>
        /// Gets or sets the collection of departments associated with this school.
        /// </summary>
        public ICollection<Department> Departments { get; set; } = new List<Department>();

        /// <summary>
        /// Gets or sets the collection of students enrolled in this school.
        /// </summary>
        public ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
