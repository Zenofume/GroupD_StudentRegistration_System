﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a user entity with details about the user's account, credentials, role, and optional link to a student.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Gets or sets the unique identifier for the user.
        /// </summary>
        [Key]
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the username for the user. For students, this is based on the StudentIDNumber.
        /// </summary>
        [Microsoft.Build.Framework.Required]
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets the hashed password for the user. Passwords should be stored securely.
        /// </summary>
        [Microsoft.Build.Framework.Required]
        public string PasswordHash { get; set; }

        /// <summary>
        /// Gets or sets the role of the user, e.g., Admin or Student.
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// Gets or sets the refresh token used for authentication purposes.
        /// </summary>
        public string? RefreshToken { get; set; }

        /// <summary>
        /// Gets or sets the expiration time for the refresh token.
        /// </summary>
        public DateTime RefreshTokenExpiryTime { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether a password reset is required for the user.
        /// </summary>
        public bool IsPasswordResetRequired { get; set; } = true;

        /// <summary>
        /// Gets or sets the optional identifier for the associated student.
        /// </summary>
        public int? StudentId { get; set; }

        /// <summary>
        /// Navigation property for linking to the associated student.
        /// </summary>
        public Student Student { get; set; }
    }
}
