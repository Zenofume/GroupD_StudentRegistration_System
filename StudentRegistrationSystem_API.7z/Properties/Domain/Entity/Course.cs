﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a course entity with an identifier, name, and code.
    /// </summary>
    public class Course
    {
        /// <summary>
        /// Gets or sets the unique identifier for the course.
        /// </summary>
        [Key]
        public int CourseId { get; set; }

        /// <summary>
        /// Gets or sets the name of the course.
        /// </summary>
        public string? CourseName { get; set; }

        /// <summary>
        /// Gets or sets the code associated with the course.
        /// </summary>
        public string? CourseCode { get; set; }
    }

    /// <summary>
    /// Represents a node in a linked list, containing a course and a reference to the next node.
    /// </summary>
    public class CourseNode
    {
        /// <summary>
        /// Gets or sets the course associated with this node.
        /// </summary>
        public Course Course { get; set; }

        /// <summary>
        /// Gets or sets the reference to the next node in the linked list.
        /// </summary>
        public CourseNode Next { get; set; }
    }

    /// <summary>
    /// Represents a linked list of course nodes, providing methods to add courses and retrieve the list of courses.
    /// </summary>
    public class LinkedList
    {
        private CourseNode _head;

        /// <summary>
        /// Adds a new course to the end of the linked list.
        /// </summary>
        /// <param name="course">The course to be added to the linked list.</param>
        public void AddCourse(Course course)
        {
            var newNode = new CourseNode { Course = course };
            if (_head == null)
            {
                _head = newNode;
            }
            else
            {
                var current = _head;
                while (current.Next != null)
                {
                    current = current.Next;
                }
                current.Next = newNode;
            }
        }

        /// <summary>
        /// Retrieves all courses from the linked list.
        /// </summary>
        /// <returns>An enumerable collection of courses.</returns>
        public IEnumerable<Course> GetCourses()
        {
            var courses = new List<Course>();
            var current = _head;
            while (current != null)
            {
                courses.Add(current.Course);
                current = current.Next;
            }
            return courses;
        }
    }
}
