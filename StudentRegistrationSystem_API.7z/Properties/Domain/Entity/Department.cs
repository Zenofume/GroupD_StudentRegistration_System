﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a department entity with details about the department and its associated students.
    /// </summary>
    public class Department
    {
        /// <summary>
        /// Gets or sets the unique identifier for the department.
        /// </summary>
        [Key]
        public int DepartmentID { get; set; }

        /// <summary>
        /// Gets or sets the name of the department.
        /// </summary>
        public string? DepartmentName { get; set; }

        /// <summary>
        /// Gets or sets the collection of students associated with this department.
        /// </summary>
        public ICollection<Student> Students { get; set; } = new List<Student>();
    }

    /// <summary>
    /// Represents a node in a tree structure, containing a department and a list of child nodes.
    /// </summary>
    public class DepartmentNode
    {
        /// <summary>
        /// Gets or sets the department associated with this node.
        /// </summary>
        public Department Department { get; set; }

        /// <summary>
        /// Gets or sets the list of child nodes under this node.
        /// </summary>
        public List<DepartmentNode> Children { get; set; } = new List<DepartmentNode>();
    }

    /// <summary>
    /// Represents a tree structure of departments with methods to add child departments.
    /// </summary>
    public class Tree
    {
        private readonly DepartmentNode _root;

        /// <summary>
        /// Initializes a new instance of the <see cref="Tree"/> class with a root department.
        /// </summary>
        /// <param name="rootDepartment">The root department of the tree.</param>
        public Tree(Department rootDepartment)
        {
            _root = new DepartmentNode { Department = rootDepartment };
        }

        /// <summary>
        /// Adds a child department to a specified parent department in the tree.
        /// </summary>
        /// <param name="parentDepartment">The parent department to which the child department will be added.</param>
        /// <param name="childDepartment">The child department to be added.</param>
        public void AddChild(Department parentDepartment, Department childDepartment)
        {
            var parentNode = FindNode(_root, parentDepartment);
            if (parentNode != null)
            {
                parentNode.Children.Add(new DepartmentNode { Department = childDepartment });
            }
        }

        /// <summary>
        /// Finds the node in the tree that corresponds to the specified department.
        /// </summary>
        /// <param name="root">The root node to start the search from.</param>
        /// <param name="department">The department to find in the tree.</param>
        /// <returns>The node corresponding to the specified department, or null if not found.</returns>
        private DepartmentNode FindNode(DepartmentNode root, Department department)
        {
            if (root.Department == department)
            {
                return root;
            }

            foreach (var child in root.Children)
            {
                var result = FindNode(child, department);
                if (result != null)
                {
                    return result;
                }
            }

            return null;
        }
    }
}
