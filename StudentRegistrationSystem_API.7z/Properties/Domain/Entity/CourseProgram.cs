﻿using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a course program entity with details about the program and its associated students.
    /// </summary>
    public class CourseProgram
    {
        /// <summary>
        /// Gets or sets the unique identifier for the course program.
        /// </summary>
        [Key]
        public int CourseProgramID { get; set; }

        /// <summary>
        /// Gets or sets the name of the course program.
        /// </summary>
        public string? CourseProgramName { get; set; }

        /// <summary>
        /// Gets or sets the level of the course program (e.g., undergraduate, postgraduate).
        /// </summary>
        public string? CourseLevel { get; set; }

        /// <summary>
        /// Gets or sets the semester in which the course program is being offered.
        /// </summary>
        public string? Semester { get; set; }

        /// <summary>
        /// Gets or sets the academic year during which the course program is conducted.
        /// </summary>
        public string? AcademicYear { get; set; }

        /// <summary>
        /// Gets or sets the collection of students enrolled in this course program.
        /// </summary>
        public ICollection<Student> Students { get; set; } = new List<Student>();
    }
}
