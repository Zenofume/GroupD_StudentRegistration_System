﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationSystem.Properties.Domain.Entity
{
    /// <summary>
    /// Represents a student entity that inherits from the User class, with details about the student's personal information, enrollment, and associated entities.
    /// </summary>
    public class Student 
    {
        /// <summary>
        /// Gets or sets the unique identifier for the student.
        /// </summary>
        [Key]
        public int StudentId { get; set; }

        /// <summary>
        /// Gets or sets the first name of the student.
        /// </summary>
        [Required]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the student.
        /// </summary>
        public string? LastName { get; set; }

        /// <summary>
        /// Gets or sets any additional names of the student.
        /// </summary>
        public string? OtherName { get; set; }

        /// <summary>
        /// Gets or sets the date of birth of the student.
        /// </summary>
        public DateTime? Dob { get; set; }

        /// <summary>
        /// Gets or sets the gender of the student.
        /// </summary>
        public string? Gender { get; set; }

        /// <summary>
        /// Gets or sets the address of the student.
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Gets or sets the nationality of the student.
        /// </summary>
        public string? Nationality { get; set; }

        /// <summary>
        /// Gets or sets the marital status of the student.
        /// </summary>
        public string? MaritialStatus { get; set; }

        /// <summary>
        /// Gets or sets the student identification number.
        /// </summary>
        [Required]
        public string StudentIDNumber { get; set; }

        /// <summary>
        /// Gets or sets the phone number of the student.
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the email address of the student.
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Gets or sets the first course the student is enrolled in.
        /// </summary>
        public string? Course1 { get; set; }

        /// <summary>
        /// Gets or sets the second course the student is enrolled in.
        /// </summary>
        public string? Course2 { get; set; }

        /// <summary>
        /// Gets or sets the third course the student is enrolled in.
        /// </summary>
        public string? Course3 { get; set; }

        /// <summary>
        /// Gets or sets the fourth course the student is enrolled in.
        /// </summary>
        public string? Course4 { get; set; }

        /// <summary>
        /// Gets or sets the fifth course the student is enrolled in.
        /// </summary>
        public string? Course5 { get; set; }

        /// <summary>
        /// Gets or sets the sixth course the student is enrolled in.
        /// </summary>
        public string? Course6 { get; set; }

        /// <summary>
        /// Gets or sets the seventh course the student is enrolled in.
        /// </summary>
        public string? Course7 { get; set; }

        /// <summary>
        /// Gets or sets the schools the student is associated with.
        /// </summary>
        public string? Schools { get; set; }

        /// <summary>
        /// Gets or sets the departments the student is associated with.
        /// </summary>
        public string? Departments { get; set; }

        /// <summary>
        /// Gets or sets the programs the student is associated with.
        /// </summary>
        public string? Programs { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the school the student is enrolled in.
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Gets or sets the school the student is enrolled in.
        /// </summary>
        public School? School { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the department the student is enrolled in.
        /// </summary>
        public int? DepartmentId { get; set; }

        /// <summary>
        /// Gets or sets the department the student is enrolled in.
        /// </summary>
        public Department? Department { get; set; }

        /// <summary>
        /// Gets or sets the identifier for the course program the student is enrolled in.
        /// </summary>
        public int? CourseProgramId { get; set; }

        /// <summary>
        /// Gets or sets the course program the student is enrolled in.
        /// </summary>
        public CourseProgram? CourseProgram { get; set; }

        /// <summary>
        /// Gets or sets the date when the student registered.
        /// </summary>
        public DateTime? DateRegister { get; set; }

        /// <summary>
        /// Gets or sets the count of updates made to the student's information.
        /// </summary>
        public int UpdateCount { get; set; } // Track number of updates
    }
}
