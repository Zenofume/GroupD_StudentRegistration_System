﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for transferring school information.
    /// </summary>
    public class SchoolDto
    {
        /// <summary>
        /// Gets or sets the name of the school.
        /// </summary>
        public string? SchoolName { get; set; }
    }

    /// <summary>
    /// Represents a Data Transfer Object (DTO) for updating school information.
    /// </summary>
    public class UpdateSchoolDto
    {
        /// <summary>
        /// Gets or sets the name of the school.
        /// This property is optional and can be used to update the school name.
        /// </summary>
        public string? SchoolName { get; set; }
    }
}
