﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for transferring department information.
    /// </summary>
    public class DepartmentDto
    {
        /// <summary>
        /// Gets or sets the name of the department.
        /// </summary>
        public string? DepartmentName { get; set; }
    }

    /// <summary>
    /// Represents a Data Transfer Object (DTO) for updating department information.
    /// </summary>
    public class UpdateDepartmentDto
    {
        /// <summary>
        /// Gets or sets the name of the department.
        /// This property is optional and can be used to update the department name.
        /// </summary>
        public string? DepartmentName { get; set; }
    }
}
