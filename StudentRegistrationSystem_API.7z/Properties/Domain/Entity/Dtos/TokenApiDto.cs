﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for transferring authentication tokens.
    /// </summary>
    public class TokenApiDto
    {
        /// <summary>
        /// Gets or sets the access token used for authenticating API requests.
        /// This token is typically short-lived and is used to authorize requests to protected resources.
        /// </summary>
        public string AccessToken { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the refresh token used to obtain a new access token when the current access token expires.
        /// This token is typically long-lived and is used to refresh the access token without requiring the user to re-authenticate.
        /// </summary>
        public string RefreshToken { get; set; } = string.Empty;
    }
}
