﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for updating student information.
    /// </summary>
    public class UpdateStudentDto
    {
        /// <summary>
        /// Gets or sets the other names of the student.
        /// </summary>
        public string? OtherName { get; set; }

        /// <summary>
        /// Gets or sets the date of birth of the student.
        /// </summary>
        public DateTime? Dob { get; set; }

        /// <summary>
        /// Gets or sets the gender of the student.
        /// </summary>
        public string? Gender { get; set; }

        /// <summary>
        /// Gets or sets the address of the student.
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Gets or sets the nationality of the student.
        /// </summary>
        public string? Nationality { get; set; }

        /// <summary>
        /// Gets or sets the marital status of the student.
        /// </summary>
        public string? MaritialStatus { get; set; }

        /// <summary>
        /// Gets or sets the phone number of the student.
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the email address of the student.
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Gets or sets the name of the first course the student is enrolled in.
        /// </summary>
        public string? Course1 { get; set; }

        /// <summary>
        /// Gets or sets the name of the second course the student is enrolled in.
        /// </summary>
        public string? Course2 { get; set; }

        /// <summary>
        /// Gets or sets the name of the third course the student is enrolled in.
        /// </summary>
        public string? Course3 { get; set; }

        /// <summary>
        /// Gets or sets the name of the fourth course the student is enrolled in.
        /// </summary>
        public string? Course4 { get; set; }

        /// <summary>
        /// Gets or sets the name of the fifth course the student is enrolled in.
        /// </summary>
        public string? Course5 { get; set; }

        /// <summary>
        /// Gets or sets the name of the sixth course the student is enrolled in.
        /// </summary>
        public string? Course6 { get; set; }

        /// <summary>
        /// Gets or sets the name of the seventh course the student is enrolled in.
        /// </summary>
        public string? Course7 { get; set; }

        /// <summary>
        /// Gets or sets the department the student belongs to.
        /// </summary>
        public string? Departments { get; set; }

        /// <summary>
        /// Gets or sets the school the student belongs to.
        /// </summary>
        public string? Schools { get; set; }

        /// <summary>
        /// Gets or sets the programs the student is enrolled in.
        /// </summary>
        public string? Programs { get; set; }

        /// <summary>
        /// Gets or sets the ID of the school the student is associated with.
        /// </summary>
        public int? SchoolId { get; set; }

        /// <summary>
        /// Gets or sets the ID of the department the student is associated with.
        /// </summary>
        public int? DepartmentId { get; set; }

        /// <summary>
        /// Gets or sets the ID of the course program the student is associated with.
        /// </summary>
        public int? CourseProgramId { get; set; }

        /// <summary>
        /// Gets or sets the date the student registered.
        /// </summary>
        public DateTime? DateRegister { get; set; }
    }
}
