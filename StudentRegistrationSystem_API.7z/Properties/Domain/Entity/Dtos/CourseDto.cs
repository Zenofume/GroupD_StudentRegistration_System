﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for transferring course information.
    /// </summary>
    public class CourseDto
    {
        /// <summary>
        /// Gets or sets the name of the course.
        /// </summary>
        public string? CourseName { get; set; }

        /// <summary>
        /// Gets or sets the code of the course.
        /// </summary>
        public string? CourseCode { get; set; }
    }

    /// <summary>
    /// Represents a Data Transfer Object (DTO) for updating course information.
    /// </summary>
    public class UpdateCourseDto
    {
        /// <summary>
        /// Gets or sets the name of the course.
        /// This property is optional and can be used to update the course name.
        /// </summary>
        public string? CourseName { get; set; }

        /// <summary>
        /// Gets or sets the code of the course.
        /// This property is optional and can be used to update the course code.
        /// </summary>
        public string? CourseCode { get; set; }
    }
}
