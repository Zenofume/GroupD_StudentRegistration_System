﻿namespace StudentRegistrationSystem.Properties.Domain.Entity.Dtos
{
    /// <summary>
    /// Represents a Data Transfer Object (DTO) for transferring course program information.
    /// </summary>
    public class CourseProgramDto
    {
        /// <summary>
        /// Gets or sets the name of the course program.
        /// </summary>
        public string? CourseProgramName { get; set; }

        /// <summary>
        /// Gets or sets the level of the course program.
        /// </summary>
        public string? CourseLevel { get; set; }

        /// <summary>
        /// Gets or sets the semester of the course program.
        /// </summary>
        public string? Semester { get; set; }

        /// <summary>
        /// Gets or sets the academic year of the course program.
        /// </summary>
        public string? AcademicYear { get; set; }
    }

    /// <summary>
    /// Represents a Data Transfer Object (DTO) for updating course program information.
    /// </summary>
    public class UpdateCourseProgramDto
    {
        /// <summary>
        /// Gets or sets the name of the course program.
        /// This property is optional and can be used to update the course program name.
        /// </summary>
        public string? CourseProgramName { get; set; }

        /// <summary>
        /// Gets or sets the level of the course program.
        /// This property is optional and can be used to update the course program level.
        /// </summary>
        public string? CourseLevel { get; set; }

        /// <summary>
        /// Gets or sets the semester of the course program.
        /// This property is optional and can be used to update the course program semester.
        /// </summary>
        public string? Semester { get; set; }

        /// <summary>
        /// Gets or sets the academic year of the course program.
        /// This property is optional and can be used to update the course program academic year.
        /// </summary>
        public string? AcademicYear { get; set; }
    }
}
