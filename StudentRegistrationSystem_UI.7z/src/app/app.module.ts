import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from "@angular/common/http";
import { HomeComponent } from './Domain/Component/home/home.component';
import {NgOptimizedImage} from "@angular/common";
import { LoginComponent } from './Domain/Component/home/login/login.component';
import { SchoolComponent } from './Domain/Component/admin/school/school.component';
import {DashboardComponent} from "./Domain/Component/admin/dashboard/dashboard.component";
import { CourseProgramComponent } from './Domain/Component/admin/course-program/course-program.component';
import { CoursesComponent } from './Domain/Component/admin/courses/courses.component';
import { DepartmentComponent } from './Domain/Component/admin/department/department.component';
import { StudentComponent } from './Domain/Component/student/student.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { StudentregistrationComponent } from './Domain/Component/admin/studentregistration/studentregistration/studentregistration.component';
import { CreatenewpasswordComponent } from './Domain/Component/home/createnewpassword/createnewpassword.component';
import {JwtHelperService} from "@auth0/angular-jwt";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    SchoolComponent,
    CourseProgramComponent,
    CoursesComponent,
    DepartmentComponent,
    StudentComponent,
    StudentregistrationComponent,
    CreatenewpasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgOptimizedImage,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    JwtHelperService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
