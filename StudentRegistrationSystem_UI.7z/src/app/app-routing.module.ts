import { NgModule} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {HomeComponent} from "./Domain/Component/home/home.component";
import {LoginComponent} from "./Domain/Component/home/login/login.component";
import {DashboardComponent} from "./Domain/Component/admin/dashboard/dashboard.component";
import {SchoolComponent} from "./Domain/Component/admin/school/school.component";
import {DepartmentComponent} from "./Domain/Component/admin/department/department.component";
import {CoursesComponent} from "./Domain/Component/admin/courses/courses.component";
import {CourseProgramComponent} from "./Domain/Component/admin/course-program/course-program.component";
import {StudentComponent} from "./Domain/Component/student/student.component";
import {StudentregistrationComponent} from "./Domain/Component/admin/studentregistration/studentregistration/studentregistration.component";
import {CreatenewpasswordComponent} from "./Domain/Component/home/createnewpassword/createnewpassword.component";


const routes: Routes = [
  {path:'', component:HomeComponent },
  {path:'login', component:LoginComponent},
  {path:'changepassword', component:CreatenewpasswordComponent},
  {path:'dashboard', component:DashboardComponent},
  {path:'school', component:SchoolComponent},
  {path:'department', component:DepartmentComponent},
  {path:'courses', component:CoursesComponent},
  {path:'courseProgram', component:CourseProgramComponent},
  {path:'student', component:StudentComponent},
  {path:'registertudent', component:StudentregistrationComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
