//export const baseApiUrl = 'https://localhost:44300';
export const baseApiUrl = 'https://localhost:7103';
