// import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
// import Swal from 'sweetalert2';
// import {
//   HttpRequest,
//   HttpHandler,
//   HttpEvent,
//   HttpInterceptor,
//   HttpErrorResponse
// } from '@angular/common/http';
// import { catchError, Observable, switchMap, throwError } from 'rxjs';
// import { AuthService } from '../services/auth.service';
// import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
// import {TokenApi} from "../Model/tokenApi";
//
// @Injectable()
// export class TokenInterceptor implements HttpInterceptor {
//
//   constructor(private auth: AuthService, private router: Router, private idle: Idle) {
//     this.setupIdleTimer();
//   }
//
//   intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
//     const myToken = this.auth.getToken();
//
//     if (myToken) {
//       request = request.clone({
//         setHeaders: { Authorization: `Bearer ${myToken}` }
//       });
//     }
//
//     return next.handle(request).pipe(
//       catchError((err: any) => {
//         if (err instanceof HttpErrorResponse) {
//           if (err.status === 401) {
//             Swal.fire({
//               icon: 'warning',
//               title: 'Warning',
//               text: 'Token is expired, Please Login again'
//             });
//             this.router.navigate(['login']);
//             return this.handleUnAuthorizedError(request, next);
//           }
//         }
//         return throwError(() => err);
//       })
//     );
//   }
//
//   handleUnAuthorizedError(req: HttpRequest<any>, next: HttpHandler) {
//     let tokenApiModel = new TokenApi();
//     tokenApiModel.accessToken = this.auth.getToken()!;
//     tokenApiModel.refreshToken = this.auth.getRefreshToken()!;
//     return this.auth.renewToken(tokenApiModel)
//       .pipe(
//         switchMap((data: TokenApi) => {
//           this.auth.storeRefreshToken(data.refreshToken);
//           this.auth.storeToken(data.accessToken);
//           req = req.clone({
//             setHeaders: { Authorization: `Bearer ${data.accessToken}` }
//           });
//           return next.handle(req);
//         }),
//         catchError((err) => {
//           Swal.fire({
//             icon: 'warning',
//             title: 'Warning',
//             text: 'Token is expired, Please Login again'
//           });
//           this.router.navigate(['login']);
//           return throwError(() => err);
//         })
//       );
//   }
//
//   private setupIdleTimer() {
//     this.idle.setIdle(180); // 3 minutes idle
//     this.idle.setTimeout(1); // Timeout after 1 second of inactivity
//     this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
//
//     this.idle.onTimeout.subscribe(() => {
//       Swal.fire({
//         icon: 'warning',
//         title: 'Warning',
//         text: 'You have been logged out due to inactivity'
//       });
//       this.auth.signOut();
//       this.router.navigate(['login']);
//     });
//
//     this.idle.watch();
//   }
// }
