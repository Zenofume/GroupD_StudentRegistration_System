import { CanActivateFn } from '@angular/router';
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  canActivate(): boolean {
    if (this.auth.isLoggedIn()) {
      return true;
    } else {
      Swal.fire({
        icon: 'error',
        title: '<strong>401</strong> <br> Access Denied',
        text: 'Please Login First!',
        showCancelButton: false, // hide the Cancel button
        confirmButtonText: 'OK',// customize the OK button text
        confirmButtonColor: '#ff7843'
      }).then((result) => {
        if (result.isConfirmed) {
          //
          this.router.navigate(['login']); // navigate to your login route only if OK is clicked
        }
      });
      return false;
    }
  }
}
