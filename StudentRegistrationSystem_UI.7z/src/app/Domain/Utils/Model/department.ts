export interface Department {
  departmentID: number;
  departmentName:string
}
