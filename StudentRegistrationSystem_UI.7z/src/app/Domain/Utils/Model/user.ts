export interface User {
  userId :number,
  firstName :string,
  lastName :string,
  username :string,
  schools :string,
  departments :string,
  programs :string,
  role :string,
  isPasswordResetRequired :boolean

}
