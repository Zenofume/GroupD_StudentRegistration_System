export interface School {
  schoolID: number;
  schoolName:string
}

