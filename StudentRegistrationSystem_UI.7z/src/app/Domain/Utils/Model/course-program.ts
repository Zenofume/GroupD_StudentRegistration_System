export interface CourseProgram {
  courseProgramID:number,
  courseProgramName: string,
  semester: string,
  academicYear: string,
}
