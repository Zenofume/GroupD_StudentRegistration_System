export class TokenApi {
accessToken! :string;
refreshToken! :string;
}
