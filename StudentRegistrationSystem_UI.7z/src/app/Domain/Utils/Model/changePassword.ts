// export interface ChangePassword {
//   changepasswordID:number,
//   username: string,
//   currentPassword: string,
//   newPassword: string
// }
