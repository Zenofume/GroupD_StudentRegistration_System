export interface Student {
  studentId: number;
  firstName: string;
  lastName?: string;
  otherName?: string;
  dob?: Date;
  gender?: string;
  address?: string;
  nationality?: string;
  maritalStatus?: string;
  studentIDNumber: string;
  phoneNumber?: string;
  email?: string;
  course1?: string;
  course2?: string;
  course3?: string;
  course4?: string;
  course5?: string;
  course6?: string;
  course7?: string;
  program?: string;
  schools?: string;
  departments?: string;
  programs?:string;
  dateRegister?: Date;
  updateCount?: number;
}
