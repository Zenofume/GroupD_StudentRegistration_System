import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {Department} from "../Model/department";
import {baseApiUrl} from "../Vars/const";
import {Student} from "../Model/student";

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http: HttpClient) { }

  getallStudent(): Observable<Student[]> {
    return this.http.get<any>(`${baseApiUrl}/api/students`).pipe(
      map(response => response.$values)
    );
  }
  getStudentId(id: number): Observable<Student> {
    return this.http.get<Student>(`${baseApiUrl}/api/students/findStudentid?studentid=${id}`);
  }

  updateStudent(updateID: any, studentData: any): Observable<any> {
    return this.http.patch<any>(`${baseApiUrl}/api/students/${updateID}`, studentData);
  }

}
