import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import {baseApiUrl} from "../Vars/const";
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userPayload: any;

  constructor(private http: HttpClient, private router: Router) {
    if (this.isLoggedIn()) {
      this.userPayload = this.decodedToken();
    }
  }

  login(LoginObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Auth/login`, LoginObj);
  }
  changePassword(ChangePasswordObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Auth/change-password`, ChangePasswordObj);
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['']);
  }

  storeToken(tokenValue: string) {
    console.log('Storing Token:', tokenValue);
    localStorage.setItem('token', tokenValue);
    this.userPayload = this.decodedToken(); // Update userPayload after storing the token
    console.log('Decoded Token Payload:', this.userPayload); // Log the decoded payload
  }



  storeRefreshToken(tokenValue: string) {
    localStorage.setItem('refreshToken', tokenValue);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getRefreshToken() {
    return localStorage.getItem('refreshToken');
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  decodedToken() {
    const jwtHelper = new JwtHelperService();
    const token = this.getToken();

    if (!token) {
      console.error('No token found');
      return null;

      console.log('Token:', token);
    }

    try {
      return jwtHelper.decodeToken(token);
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  }

  isTokenExpired(): boolean {
    const jwtHelper = new JwtHelperService();
    const token = this.getToken();
    return token ? jwtHelper.isTokenExpired(token) : true;
  }


  getRoleFromToken() {
    if (this.userPayload && this.userPayload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"]) {
      return this.userPayload["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
    }
    return null;
  }


  // renewToken(tokenApi: TokenApiModel) {
  //   return this.http.post<any>(${baseApiUrl}/api/User/refresh, tokenApi);
  // }

  getfullNameFromToken(){
    if(this.userPayload && this.userPayload.unique_name)
      return this.userPayload.unique_name;
    return 'Guest';
  }

}
