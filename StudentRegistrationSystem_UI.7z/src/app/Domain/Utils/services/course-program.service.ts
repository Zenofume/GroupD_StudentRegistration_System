import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {baseApiUrl} from "../Vars/const";
import {CourseProgram} from "../Model/course-program";


@Injectable({
  providedIn: 'root'
})
export class CourseProgramService {

  constructor(private http: HttpClient) { }


  getallCourseProgram(): Observable<CourseProgram[]> {
    return this.http.get<any>(`${baseApiUrl}/api/CourseProgram`).pipe(
      map(response => response.$values)
    );
  }
  getCourseProgram(id: number): Observable<CourseProgram> {
    return this.http.get<CourseProgram>(`${baseApiUrl}/api/CourseProgram/findCourseProgramlid?courseProgramid=${id}`);
  }

  addCourseProgram(CourseProgramObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/CourseProgram/addcourseprogram`, CourseProgramObj);
  }
  deleteCourseProgram(courseProgramID: number): Observable<any> {
    return this.http.post<any>(`${baseApiUrl}/api/CourseProgram/${courseProgramID}`, {});

  }

  updateCourseProgramID(updateID: any, courseProgramData: any): Observable<any> {
    return this.http.patch<any>(`${baseApiUrl}/api/CourseProgram/${updateID}`, courseProgramData);
  }



}
