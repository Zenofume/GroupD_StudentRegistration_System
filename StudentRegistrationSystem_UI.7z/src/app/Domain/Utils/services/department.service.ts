import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import { map, Observable} from "rxjs";
import {baseApiUrl} from "../Vars/const";
import {Department} from "../Model/department";

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor(private http: HttpClient) { }

  getallDepartment(): Observable<Department[]> {
    return this.http.get<any>(`${baseApiUrl}/api/Department`).pipe(
      map(response => response.$values)
    );
  }
  getDepartmentId(id: number): Observable<Department> {
    return this.http.get<Department>(`${baseApiUrl}/api/Department/finddepartmentid?departmentid=${id}`);
  }



  addDepartment(departmentObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Department/adddepartment`, departmentObj);
  }
  deleteDepartment(departmentID: number): Observable<any> {
    return this.http.post<any>(`${baseApiUrl}/api/Department/${departmentID}`, {});
  }

  updateDepartment(updateID: any, departmentData: any): Observable<any> {
    return this.http.patch<any>(`${baseApiUrl}/api/Department/${updateID}`, departmentData);
  }



}
