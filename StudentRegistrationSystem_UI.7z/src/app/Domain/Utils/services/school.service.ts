import { Injectable } from '@angular/core';
import {map, Observable} from "rxjs";
import {baseApiUrl} from "../Vars/const";
import {HttpClient} from "@angular/common/http";
import {School} from "../Model/school";

@Injectable({
  providedIn: 'root'
})
export class SchoolService {

  constructor( private http: HttpClient) { }


  getallSchool(): Observable<School[]> {
    return this.http.get<any>(`${baseApiUrl}/api/School`).pipe(
      map(response => response.$values)
    );
  }
  getSchoolId(id: number): Observable<School> {
    return this.http.get<School>(`${baseApiUrl}/api/School/findschoolid?schoolid=${id}`);
  }

  addSchool(schoolObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/School/addschool`, schoolObj);
  }
  deleteSchool(schoolID: number): Observable<any> {
    return this.http.post<any>(`${baseApiUrl}/api/School/${schoolID}`, {});

  }

  updateSchool(updateID: any, schoolData: any): Observable<any> {
    return this.http.patch<any>(`${baseApiUrl}/api/School/${updateID}`, schoolData);
  }



}
