import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {baseApiUrl} from "../Vars/const";
import {Course} from "../Model/course";

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http: HttpClient) { }


  getallCourse(): Observable<Course[]> {
    return this.http.get<any>(`${baseApiUrl}/api/Course`).pipe(
      map(response => response.$values)
    );
  }
  getCourse(id: number): Observable<Course> {
    return this.http.get<Course>(`${baseApiUrl}/api/Course/findCourseid?courseid=${id}`);
  }

  addCourse(CourseObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Course/addcourse`, CourseObj);
  }
  deleteCourse(courseID: number): Observable<any> {
    return this.http.post<any>(`${baseApiUrl}/api/Course/${courseID}`, {});

  }

  updateCourse(updateID: any, courseData: any): Observable<any> {
    return this.http.patch<any>(`${baseApiUrl}/api/Course/${updateID}`, courseData);
  }



}
