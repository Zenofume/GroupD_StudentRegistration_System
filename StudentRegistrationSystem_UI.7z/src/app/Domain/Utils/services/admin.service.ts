import { Injectable } from '@angular/core';
import {baseApiUrl} from "../Vars/const";
import {HttpClient} from "@angular/common/http";
import {map, Observable} from "rxjs";
import {CourseProgram} from "../Model/course-program";
import {User} from "../Model/user";

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }

  createUserAccount(UserAccountObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Admin/create-user`, UserAccountObj);
  }

  resetUserAccount(UserResetObj: any) {
    return this.http.post<any>(`${baseApiUrl}/api/Admin/reset-password`, UserResetObj);
  }

  getallUsers(): Observable<User[]> {
    return this.http.get<any>(`${baseApiUrl}/api/Admin`).pipe(
      map(response => response.$values)
    );
  }


}
