import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import ValidateForm from "../../../Utils/validationform";
import { AuthService } from "../../../Utils/services/auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public loginForm!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });



  }


  onSubmit() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe(
        (response) => {
          const token = response.token;
          if (token) {
            this.authService.storeToken(token);

            const role = this.authService.getRoleFromToken();
            console.log('Role extracted from token:', role); // Debug log to check the role

            if (role === 'Admin') {
              this.router.navigate(['/dashboard']);
            } else if (role === 'Student') {
              this.router.navigate(['/registertudent']);
            } else {
              Swal.fire('Error', 'Unauthorized role!', 'error');
            }
          } else {
            Swal.fire('Error', 'No token received!', 'error');
          }
        },
        (error) => {
          const errorMessage = error.error?.message || 'Login failed! Please try again later.';
          Swal.fire('Error', errorMessage, 'error');
        }
      );
    } else {
      ValidateForm.validateAllFormFields(this.loginForm);
      Swal.fire('Error', 'Please fill in all required fields.', 'error');
    }
  }




}
