import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';
import ValidateForm from "../../../Utils/validationform";
import { AuthService } from "../../../Utils/services/auth.service";

@Component({
  selector: 'app-createnewpassword',
  templateUrl: './createnewpassword.component.html',
  styleUrls: ['./createnewpassword.component.css']
})
export class CreatenewpasswordComponent implements OnInit {
  public changePasswordForm!: FormGroup;
  type: string = 'password';
  isText: boolean = false;
  eyeIcon: string = 'fa-eye-slash';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.changePasswordForm = this.fb.group({
      username: ['', Validators.required],
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  hideShowPass() {
    this.isText = !this.isText;
    this.eyeIcon = this.isText ? 'fa-eye' : 'fa-eye-slash';
    this.type = this.isText ? 'text' : 'password';
  }

  changePassword() {
    if (this.changePasswordForm.valid) {
      Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to change your password?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, change it!'
      }).then((result) => {
        if (result.isConfirmed) {
          this.authService.changePassword(this.changePasswordForm.value)
            .subscribe({
              next: (res) => {
                // Check for successful response structure
                if (res && res.message) {
                  Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: res.message,
                    timer: 5000,
                    timerProgressBar: true,
                    showConfirmButton: false
                  }).then(() => {
                    // Navigate to the login page
                    this.router.navigate(['/login']);
                  });
                } else {
                  Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Unexpected response format.',
                    timer: 5000,
                    timerProgressBar: true,
                    showConfirmButton: false
                  });
                }
              },
              error: (err) => {
                const errorMessage = err.error?.message || 'An error occurred. Please try again.';
                Swal.fire({
                  icon: 'error',
                  title: 'Error',
                  text: errorMessage,
                  timer: 5000,
                  timerProgressBar: true,
                  showConfirmButton: false
                });
              },
            });
        }
      });
    } else {
      ValidateForm.validateAllFormFields(this.changePasswordForm);
      Swal.fire('Error', 'Please fill in all required fields correctly.', 'error');
    }
  }



  private passwordMatchValidator(formGroup: FormGroup) {
    const newPassword = formGroup.get('newPassword')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;
    return newPassword === confirmPassword ? null : { mismatch: true };
  }
}
