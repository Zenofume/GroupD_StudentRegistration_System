import { Component } from '@angular/core';
import {Student} from "../../../../Utils/Model/student";
import {StudentService} from "../../../../Utils/services/student.service";
import {ActivatedRoute, Router} from "@angular/router";
import Swal from "sweetalert2";
import * as XLSX from "xlsx";
import {saveAs} from "file-saver";

@Component({
  selector: 'app-studentregistration',
  templateUrl: './studentregistration.component.html',
  styleUrl: './studentregistration.component.css'
})
export class StudentregistrationComponent {

  student: Student[] = [];
  totalcountofStudent: number = 0;
  searchUser: string = "";
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 0;
  totalPagesArray: number[] = [];
  courses: number[] = [];
  updateStudentRequest: Student = {
    studentId :0,
    firstName: '',
    lastName: '',
    otherName: '',
    dob: undefined,
    gender: '',
    address: '',
    nationality: '',
    maritalStatus: '',
    studentIDNumber: '',
    phoneNumber: '',
    email: '',
    course1: '',
    course2: '',
    course3: '',
    course4: '',
    course5: '',
    course6: '',
    course7: ''
  };

  constructor(
    private studentService: StudentService,
    private router:Router,
    private route: ActivatedRoute
  ){}

  ngOnInit(): void {
    this.loadData();
    this.route.paramMap.subscribe({
      next: (params) => {
        const id = parseInt(params.get('id') || '0', 10);

        if (id) {
          this.studentService.getStudentId(id).subscribe({
            next: (stud) => {
              this.updateStudentRequest = stud;
            },
            error: (err) => {
              console.error('Error fetching Student Record:', err);
            }
          });
        } else {
          // Optionally handle the case when ID is invalid
        }
      },
      error: (err) => {
        console.error('Error in paramMap subscription:', err);
      }
    });
  }

  loadData(): void {
    this.studentService.getallStudent().subscribe((data: Student[]) => {
      this.student = data; // Ensure the  course program list is populated
      this.totalcountofStudent = this.student.length;
      this.calculateTotalPages();
    });
  }


  onEditClick(studentID: number): void {
    this.studentService.getStudentId(studentID).subscribe({
      next: (stud) => {
        this.updateStudentRequest = stud;
        console.log('Course Program data:', stud); // Log the  course program data
      },
      error: (err) => {
        console.error('Error fetching Student Record :', err); // Log any errors
      }
    });
  }

  updateStudent(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to update this Student ?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Proceed with the update
        this.studentService.updateStudent(this.updateStudentRequest.studentId, this.updateStudentRequest)
          .subscribe({
            next: (response) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Student Registered Successfully!',
                timer: 3000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Refreshes the page upon successful update
              });
            },
            error: (error) => {
              const errorMessage = error.error?.message || 'Failed to update Student. Please try again later.';
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
              console.error('Error updating Student :', error);
            }
          });
      }
    });
  }







  filteredUser(): Student[] {
    return this.student.filter(student =>
      student.firstName.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.lastName?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.otherName?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.studentIDNumber.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.email?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.phoneNumber?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.gender?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.nationality?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.maritalStatus?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course1?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course2?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course3?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course4?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course5?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course6?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      student.course7?.toLowerCase().includes(this.searchUser.toLowerCase())
    );
  }


  paginatedUser(): Student[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredUser().slice(start, end);
  }

  calculateTotalPages(): void {
    const totalFilteredUser = this.filteredUser().length;
    this.totalPages = Math.ceil(totalFilteredUser / this.itemsPerPage);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  onItemsPerPageChanged(newValue: number) {
    this.itemsPerPage = newValue;
    this.currentPage = 1;
    this.calculateTotalPages();
  }
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  exportToExcel(): void {
    const filteredData = this.filteredUser().map(student => ({
      firstName: student.firstName,
      lastName: student.lastName || '',
      otherName: student.otherName || '',
      studentIDNumber: student.studentIDNumber,
      email: student.email || '',
      phoneNumber: student.phoneNumber || '',
      gender: student.gender || '',
      nationality: student.nationality || '',
      maritalStatus: student.maritalStatus || '',
      course1: student.course1 || '',
      course2: student.course2 || '',
      course3: student.course3 || '',
      course4: student.course4 || '',
      course5: student.course5 || '',
      course6: student.course6 || '',
      course7: student.course7 || ''
    }));

    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'Filtered Students');
  }


  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(data, `${fileName}_export_${new Date().getTime()}${EXCEL_EXTENSION}`);
    window.location.reload();
  }
}

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
