import { Component } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { CourseProgram } from "../../../Utils/Model/course-program";
import { CourseProgramService } from "../../../Utils/services/course-program.service";

/**
 * Component for managing Course Programs.
 * This component handles CRUD operations, pagination, search, and Excel export functionalities.
 */
@Component({
  selector: 'app-course-program',
  templateUrl: './course-program.component.html',
  styleUrls: ['./course-program.component.css']
})
export class CourseProgramComponent {
  courseProgram: CourseProgram[] = [];
  totalcountofCourseProgram: number = 0;
  searchUser: string = "";
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 0;
  totalPagesArray: number[] = [];
  newCourseProgram: any = {};

  updateCourseProgramRequest: CourseProgram = {
    courseProgramID: 0,
    courseProgramName: '',
    semester: '',
    academicYear: ''
  };

  /**
   * Constructs the component and injects the required services.
   * @param courseProgramService Service for managing Course Programs.
   * @param router Router service for navigation.
   * @param route ActivatedRoute service for accessing route parameters.
   */
  constructor(
    private courseProgramService: CourseProgramService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  /**
   * Initializes the component by loading data and setting up route parameters.
   */
  ngOnInit(): void {
    this.loadData();
    this.route.paramMap.subscribe({
      next: (params) => {
        const id = parseInt(params.get('id') || '0', 10);
        if (id) {
          this.courseProgramService.getCourseProgram(id).subscribe({
            next: (coursepro) => {
              this.updateCourseProgramRequest = coursepro;
            },
            error: (err) => {
              console.error('Error fetching Course Program:', err);
            }
          });
        }
      },
      error: (err) => {
        console.error('Error in paramMap subscription:', err);
      }
    });
  }

  /**
   * Loads all course programs from the service and calculates pagination details.
   */
  loadData(): void {
    this.courseProgramService.getallCourseProgram().subscribe((data: CourseProgram[]) => {
      this.courseProgram = data;
      this.totalcountofCourseProgram = this.courseProgram.length;
      this.calculateTotalPages();
    });
  }

  /**
   * Prompts the user for confirmation and adds a new course program if confirmed.
   */
  addCourseProgram(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to add this Course Program?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, add it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.courseProgramService.addCourseProgram(this.newCourseProgram)
          .subscribe({
            next: (res) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.Message,
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload();
              });
            },
            error: (err) => {
              const errorMessage = err.error?.message || 'Failed to add Course Program. Please check your connection to the database';
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false
              });
            }
          });
      }
    });
  }

  /**
   * Fetches and logs the course program data to be edited.
   * @param courseProgramID ID of the course program to be edited.
   */
  onEditClick(courseProgramID: number): void {
    this.courseProgramService.getCourseProgram(courseProgramID).subscribe({
      next: (coursepro) => {
        this.updateCourseProgramRequest = coursepro;
        console.log('Course Program data:', coursepro);
      },
      error: (err) => {
        console.error('Error fetching Course Program:', err);
      }
    });
  }

  /**
   * Prompts the user for confirmation and updates the course program if confirmed.
   */
  updateCourseprogram(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to update this Course Program?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.courseProgramService.updateCourseProgramID(this.updateCourseProgramRequest.courseProgramID, this.updateCourseProgramRequest)
          .subscribe({
            next: (response) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Course Program updated successfully!',
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload();
              });
            },
            error: (error) => {
              const errorMessage = error.error?.message || 'Failed to update Course Program. Please try again later.';
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false
              });
              console.error('Error updating Course Program:', error);
            }
          });
      }
    });
  }

  /**
   * Prompts the user for confirmation and deletes the course program if confirmed.
   * @param CourseProgramID ID of the course program to be deleted.
   */
  deleteCourseProgram(CourseProgramID: number): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to delete this Course Program?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.courseProgramService.deleteCourseProgram(CourseProgramID).subscribe({
          next: (res) => {
            Swal.fire({
              icon: 'success',
              title: 'Deleted!',
              text: res.Message,
              timer: 3000,
              timerProgressBar: true,
              showConfirmButton: false
            }).then(() => {
              let currentUrl = this.router.url;
              this.router
                .navigateByUrl('/', { skipLocationChange: true })
                .then(() => {
                  this.router.navigate([currentUrl]);
                });
            });
          },
          error: (err) => {
            const errorMessage = err.error?.message || 'Failed to delete Course Program. Please try again later.';
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: errorMessage,
              timer: 5000,
              timerProgressBar: true,
              showConfirmButton: false
            });
          }
        });
      }
    });
  }

  /**
   * Filters the list of course programs based on the search criteria.
   * @returns An array of filtered course programs.
   */
  filteredUser(): CourseProgram[] {
    return this.courseProgram.filter(coursepro =>
      coursepro.courseProgramName?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      coursepro.semester?.toLowerCase().includes(this.searchUser.toLowerCase()) ||
      coursepro.academicYear.toLowerCase().includes(this.searchUser.toLowerCase())
    );
  }

  /**
   * Returns a paginated subset of the filtered course programs.
   * @returns A subset of filtered course programs based on the current page and items per page.
   */
  paginatedUser(): CourseProgram[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredUser().slice(start, end);
  }

  /**
   * Calculates the total number of pages based on the filtered data and items per page.
   */
  calculateTotalPages(): void {
    const totalFilteredUser = this.filteredUser().length;
    this.totalPages = Math.ceil(totalFilteredUser / this.itemsPerPage);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  /**
   * Sets the current page to the specified page number.
   * @param page The page number to navigate to.
   */
  goToPage(page: number): void {
    this.currentPage = page;
  }

  /**
   * Updates the number of items per page and resets the current page to 1.
   * @param newValue The new number of items per page.
   */
  onItemsPerPageChanged(newValue: number) {
    this.itemsPerPage = newValue;
    this.currentPage = 1;
    this.calculateTotalPages();
  }

  /**
   * Moves to the next page if not already on the last page.
   */
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  /**
   * Moves to the previous page if not already on the first page.
   */
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  /**
   * Exports the filtered list of course programs to an Excel file.
   */
  exportToExcel(): void {
    const filteredData = this.filteredUser().map(courseprogram => ({
      courseProgramName: courseprogram.courseProgramName,
      semester: courseprogram.semester,
      academicYear: courseprogram.academicYear
    }));
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'Filtered course program');
  }

  /**
   * Saves the Excel file with the specified buffer and file name.
   * @param buffer The buffer containing the Excel file data.
   * @param fileName The name of the file to be saved.
   */
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(data, `${fileName}_export_${new Date().getTime()}${EXCEL_EXTENSION}`);
    window.location.reload();
  }
}

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
