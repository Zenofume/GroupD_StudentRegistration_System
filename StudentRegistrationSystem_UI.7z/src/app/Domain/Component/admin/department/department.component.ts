import { Component, OnInit } from '@angular/core';
import { Department } from "../../../Utils/Model/department";
import { DepartmentService } from "../../../Utils/services/department.service";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import Swal from "sweetalert2";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css'] // fixed styleUrls
})
export class DepartmentComponent implements OnInit {

  department: Department[] = [];
  totalcountofDepartment: number = 0;
  searchUser: string = "";
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 0;
  totalPagesArray: number[] = [];
  newDepartment: any={};
  // updateDepartmentRequest: any = {};
  updateDepartmentRequest: Department = {
    departmentID :0,
    departmentName:''
  };

  constructor(
    private departmentService: DepartmentService,
    private router:Router,
    private route: ActivatedRoute
  ){}
  ngOnInit(): void {
    this.loadData();
    this.route.paramMap.subscribe({
      next: (params) => {
        const id = parseInt(params.get('id') || '0', 10);

        if (id) {
          this.departmentService.getDepartmentId(id).subscribe({
            next: (depart) => {
              this.updateDepartmentRequest = depart;
            },
            error: (err) => {
              console.error('Error fetching department:', err);
            }
          });
        } else {
          // Optionally handle the case when ID is invalid
        }
      },
      error: (err) => {
        console.error('Error in paramMap subscription:', err);
      }
    });
  }

  loadData(): void {
    this.departmentService.getallDepartment().subscribe((data: Department[]) => {
      this.department = data; // Ensure the department list is populated
      this.totalcountofDepartment = this.department.length;
      this.calculateTotalPages();
    });
  }

  addDepartment(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to add this department?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, add it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Submit the form
        this.departmentService.addDepartment(this.newDepartment)
          .subscribe({
            next: (res) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.Message ,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Reloads the page
              });
            },
            error: (err) => {
              const errorMessage = err.error?.message || 'Failed to add department. Please check your connection to the database' ;

              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
            },
          });
      }
    });
  }
  onEditClick(departmentID: number): void {
    this.departmentService.getDepartmentId(departmentID).subscribe({
      next: (depart) => {
        this.updateDepartmentRequest = depart;
        console.log('Department data:', depart); // Log the department data
      },
      error: (err) => {
        console.error('Error fetching department:', err); // Log any errors
      }
    });
  }

  updateDepartment(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to update this department?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Proceed with the update
        this.departmentService.updateDepartment(this.updateDepartmentRequest.departmentID, this.updateDepartmentRequest)
          .subscribe({
            next: (response) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'Department updated successfully!',
                timer: 3000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Refreshes the page upon successful update
              });
            },
            error: (error) => {
              const errorMessage = error.error?.message || 'Failed to update department. Please try again later.';
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
              console.error('Error updating department:', error);
            }
          });
      }
    });
  }





  deleteDepartment(departmentID: number): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to delete this Department?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.departmentService.deleteDepartment(departmentID).subscribe({
          next: (res) => {
            Swal.fire({
              icon: 'success',
              title: 'Deleted!',
              text: res.Message ,
              timer: 3000, // Duration in milliseconds
              timerProgressBar: true,
              showConfirmButton: false
            }).then(() => {
              // Refresh the page or navigate
              let currentUrl = this.router.url;
              this.router
                .navigateByUrl('/', { skipLocationChange: true })
                .then(() => {
                  this.router.navigate([currentUrl]);
                });
            });
          },
          error: (err) => {
            const errorMessage = err.error?.message || 'Failed to add department. Please check your connection to the database' ;

            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: errorMessage ||'Failed to delete Department. Please try again later.',
              timer: 5000, // Duration in milliseconds
              timerProgressBar: true,
              showConfirmButton: false
            });
          }
        });
      }
    });
  }

  filteredUser(): Department[] {
    return this.department.filter(dept =>
      dept.departmentName?.toLowerCase().includes(this.searchUser.toLowerCase())
    );
  }

  paginatedUser(): Department[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredUser().slice(start, end);
  }

  calculateTotalPages(): void {
    const totalFilteredUser = this.filteredUser().length;
    this.totalPages = Math.ceil(totalFilteredUser / this.itemsPerPage);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  onItemsPerPageChanged(newValue: number) {
    this.itemsPerPage = newValue;
    this.currentPage = 1;
    this.calculateTotalPages();
  }
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  exportToExcel(): void {
    const filteredData = this.filteredUser().map(department => ({
      departmentName: department.departmentName,
    }));
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'FilteredDepartments');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(data, `${fileName}_export_${new Date().getTime()}${EXCEL_EXTENSION}`);
    window.location.reload();
  }
}

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
