import { Component } from '@angular/core';
import {SchoolService} from "../../../Utils/services/school.service";
import {School} from "../../../Utils/Model/school";
import {DepartmentService} from "../../../Utils/services/department.service";
import {Department} from "../../../Utils/Model/department";
import {CourseProgramService} from "../../../Utils/services/course-program.service";
import {CourseProgram} from "../../../Utils/Model/course-program";
import Swal from "sweetalert2";
import {AdminService} from "../../../Utils/services/admin.service";
import {User} from "../../../Utils/Model/user";
import {Student} from "../../../Utils/Model/student";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  schools: School[] = [];
  departments: Department[] = [];
  totalcountofSchool: number = 0;
  totalcountofDepartment: number = 0;


  totalcountofUser: number = 0;
  user: User[] = [];
  newReset: any={};
  newUser: any={};
  searchUser: string = "";
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 0;
  totalPagesArray: number[] = [];
  newDepartment: any={};

  constructor(private schoolService: SchoolService, private departmentService:DepartmentService,    private adminService: AdminService, private courseProgramService: CourseProgramService ) {}

  ngOnInit(): void {
    this.loadData();
    this.schoolService.getallSchool().subscribe((data: School[]) => {
      this.schools = data;
      this.totalcountofSchool = this.schools.length; // Update the total count
    });
    this.departmentService.getallDepartment().subscribe((data: Department[]) => {
      this.departments = data;
      this.totalcountofDepartment = this.departments.length; // Update the total count
    });
    this.adminService.getallUsers().subscribe((data: User[]) => {
      this.user = data;
      this.totalcountofUser = this.user.length; // Update the total count
    });


  }
  loadData(): void {
    this.adminService.getallUsers().subscribe((data: User[]) => {
      this.user = data; // Ensure the  course program list is populated
      this.totalcountofUser= this.user.length;
      this.calculateTotalPages();
    });
  }

  addUser(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to add this User?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, add it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Submit the form
        this.adminService.createUserAccount(this.newUser)
          .subscribe({
            next: (res) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.Message ,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Reloads the page
              });
            },
            error: (err) => {
              const errorMessage = err.error?.message || 'Failed to add a User. Please check your connection to the database' ;

              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
            },
          });
      }
    });
  }

  resetUser(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to reset this User Account?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, add it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Submit the form
        this.adminService.resetUserAccount(this.newReset)
          .subscribe({
            next: (res) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.Message ,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Reloads the page
              });
            },
            error: (err) => {
              const errorMessage = err.error?.message || 'Failed to reset a User Account. Please check your connection to the database' ;

              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
            },
          });
      }
    });
  }


  filteredUser(): User[] {
    return this.user.filter(use =>
      (use.firstName?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.lastName?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.username?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.schools?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.departments?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.programs?.toLowerCase() || '').includes(this.searchUser.toLowerCase()) ||
      (use.role?.toLowerCase() || '').includes(this.searchUser.toLowerCase())
    );
  }



  paginatedUser(): User[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredUser().slice(start, end);
  }

  calculateTotalPages(): void {
    const totalFilteredUser = this.filteredUser().length;
    this.totalPages = Math.ceil(totalFilteredUser / this.itemsPerPage);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  onItemsPerPageChanged(newValue: number) {
    this.itemsPerPage = newValue;
    this.currentPage = 1;
    this.calculateTotalPages();
  }
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
}
