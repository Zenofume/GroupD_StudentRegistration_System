import {ActivatedRoute, Router} from "@angular/router";
import {Component} from "@angular/core";
import {School} from "../../../Utils/Model/school";
import {SchoolService} from "../../../Utils/services/school.service";
import Swal from "sweetalert2";
import {saveAs} from "file-saver";
import * as XLSX from "xlsx";


@Component({
  selector: 'app-school',
  templateUrl: './school.component.html',
  styleUrl: './school.component.css'
})
export class SchoolComponent {

  school: School[] = [];
  totalcountofSchool: number = 0;
  searchUser: string = "";
  currentPage: number = 1;
  itemsPerPage: number = 5;
  totalPages: number = 0;
  totalPagesArray: number[] = [];
  newSchool: any={};

  updateSchoolRequest: School = {
    schoolID :0,
    schoolName:''
  };

  constructor(
    private schoolService: SchoolService,
    private router:Router,
    private route: ActivatedRoute
  ){}

  ngOnInit(): void {
    this.loadData();
    this.route.paramMap.subscribe({
      next: (params) => {
        const id = parseInt(params.get('id') || '0', 10);

        if (id) {
          this.schoolService.getSchoolId(id).subscribe({
            next: (sch) => {
              this.updateSchoolRequest = sch;
            },
            error: (err) => {
              console.error('Error fetching school:', err);
            }
          });
        } else {
          // Optionally handle the case when ID is invalid
        }
      },
      error: (err) => {
        console.error('Error in paramMap subscription:', err);
      }
    });
  }

  loadData(): void {
    this.schoolService.getallSchool().subscribe((data: School[]) => {
      this.school = data; // Ensure the school list is populated
      this.totalcountofSchool = this.school.length;
      this.calculateTotalPages();
    });
  }

  addSchool(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to add this school?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, add it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Submit the form
        this.schoolService.addSchool(this.newSchool)
          .subscribe({
            next: (res) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.Message ,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Reloads the page
              });
            },
            error: (err) => {
              const errorMessage = err.error?.message || 'Failed to add school. Please check your connection to the database' ;

              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
            },
          });
      }
    });
  }
  onEditClick(schoolID: number): void {
    this.schoolService.getSchoolId(schoolID).subscribe({
      next: (sch) => {
        this.updateSchoolRequest = sch;
        console.log('School data:', sch); // Log the school data
      },
      error: (err) => {
        console.error('Error fetching school:', err); // Log any errors
      }
    });
  }

  updateSchool(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to update this school?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, update it!'
    }).then((result) => {
      if (result.isConfirmed) {
        // Proceed with the update
        this.schoolService.updateSchool(this.updateSchoolRequest.schoolID, this.updateSchoolRequest)
          .subscribe({
            next: (response) => {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'School updated successfully!',
                timer: 3000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              }).then(() => {
                window.location.reload(); // Refreshes the page upon successful update
              });
            },
            error: (error) => {
              const errorMessage = error.error?.message || 'Failed to update school. Please try again later.';
              Swal.fire({
                icon: 'error',
                title: 'Error',
                text: errorMessage,
                timer: 5000, // Duration in milliseconds
                timerProgressBar: true,
                showConfirmButton: false
              });
              console.error('Error updating school:', error);
            }
          });
      }
    });
  }





  deleteSchool(schoolID: number): void {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to delete this School?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.schoolService.deleteSchool(schoolID).subscribe({
          next: (res) => {
            Swal.fire({
              icon: 'success',
              title: 'Deleted!',
              text: res.Message ,
              timer: 3000, // Duration in milliseconds
              timerProgressBar: true,
              showConfirmButton: false
            }).then(() => {
              // Refresh the page or navigate
              let currentUrl = this.router.url;
              this.router
                .navigateByUrl('/', { skipLocationChange: true })
                .then(() => {
                  this.router.navigate([currentUrl]);
                });
            });
          },
          error: (err) => {
            const errorMessage = err.error?.message || 'Failed to add school. Please check your connection to the database' ;

            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: errorMessage ||'Failed to delete school. Please try again later.',
              timer: 5000, // Duration in milliseconds
              timerProgressBar: true,
              showConfirmButton: false
            });
          }
        });
      }
    });
  }

  filteredUser(): School[] {
    return this.school.filter(sch =>
      sch.schoolName?.toLowerCase().includes(this.searchUser.toLowerCase())
    );
  }

  paginatedUser(): School[] {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    const end = start + this.itemsPerPage;
    return this.filteredUser().slice(start, end);
  }

  calculateTotalPages(): void {
    const totalFilteredUser = this.filteredUser().length;
    this.totalPages = Math.ceil(totalFilteredUser / this.itemsPerPage);
    this.totalPagesArray = Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToPage(page: number): void {
    this.currentPage = page;
  }

  onItemsPerPageChanged(newValue: number) {
    this.itemsPerPage = newValue;
    this.currentPage = 1;
    this.calculateTotalPages();
  }
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  exportToExcel(): void {
    const filteredData = this.filteredUser().map(school => ({
      schoolName: school.schoolName,
    }));
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, 'FilteredSchool');
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    saveAs(data, `${fileName}_export_${new Date().getTime()}${EXCEL_EXTENSION}`);
    window.location.reload();
  }
}

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
